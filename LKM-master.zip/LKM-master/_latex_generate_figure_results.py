from __future__ import print_function
import os, subprocess
from collections import defaultdict
from util.constants import *

latex_folder = "util_latex"
fp_latex_template = os.path.join(latex_folder, "fig_doc_template.tex")

kw_figures_caption = "FIGURE CAPTION"  # the caption of the set of figures
kw_doc_des = "FILL FIGURE DESCRIPTION HERE"  # the overall description of the set of figures, i.e., observations, notations

kw_minipage_blocks = "MINIPAGE BLOCKS"
kw_newline_step = "NEWLINE_STEP"   # enter a new line every <newline_step> sub-figures
kw_minipage_split = "MINIPAGE SPLIT"  # split sub-figures into separate figure sets, if the number of sub-figures > <minipage_split>

# specify the following info for each sub-figure
# \begin{minipage}{<minipage_width>\columnwidth}
#     \centering
#     \includegraphics[scale=<subfig_scale>]{<subfig_path>}\\
#     (1) <subfig_title>
# \end{minipage}
kw_subfig_path = "SUBFIG_PATH_LIST"
kw_subfig_title = "SUBFIG_TITLE_LIST"
kw_subfig_scale = "SUBFIG_SCALE"
kw_minipage_width = "MINIPAGE_WIDTH"


"""
Experiments and figures folder
"""

# using_more=False: show "_nmt_infer"  -- from nmt3_test
# using_more=True: show "_nmt_more_infer" -- from nmt4_test


def main():
    for using_more in [False, True][1:]:
        if using_more:
            base_infer_folder = FOLDER_NMT_MORE_INFER
        else:
            base_infer_folder = FOLDER_NMT_INFER

        for month in ["201711"]:
            this_fig_folder = os.path.join(base_infer_folder, FOLDER_FIGS + "_" + col_type, month)
            if not os.path.exists(this_fig_folder):
                continue
            this_res_folder = os.path.join(FOLDER_SUMMARY, col_type)
            if not os.path.exists(this_res_folder):
                os.makedirs(this_res_folder)

            day_list, model_list = set(), set()
            for fn in os.listdir(this_fig_folder):
                src, tgt, cur_day, which = fn.replace(".pdf", "").split("+")
                day_list.add(cur_day)
                model_list.add(src + "+" + tgt)
            day_list = sorted(day_list)
            model_list = sorted(model_list)

            plot_input_and_infer_files_for_every_model(month, model_list, day_list, this_fig_folder, this_res_folder)


def plot_input_and_infer_files_for_every_model(month, model_list, day_list, figure_folder, res_folder):
    day_list_str = "".join([x[-2:] for x in day_list])
    figure_out = os.path.join(res_folder, month + "_" + day_list_str+ ".pdf")

    fig_scale = 0.6
    minipage_width = 0.48
    dict_figures = defaultdict(list)

    fig_names = []
    for model in model_list:
        for cur_day in day_list:
            fig_names.append(model + "+" + cur_day + "+input.pdf")
            fig_names.append(model + "+" + cur_day + "+" + kw_infer + ".pdf")

    for fn in fig_names:
        dict_figures[kw_subfig_path].append(os.path.join(figure_folder, fn))
        _tmp = fn.split(".")[0].split("_")
        # dict_figures[kw_subfig_title].append(subfig_caption)
        dict_figures[kw_subfig_title].append("")
        dict_figures[kw_subfig_scale].append(fig_scale)
        dict_figures[kw_minipage_width].append(minipage_width)

    # describe the observations of the figures in this document
    dict_figures[kw_figures_caption] = month
    dict_figures[kw_doc_des] = ""

    # insert "\newline" every <newline_step> minipages
    dict_figures[kw_newline_step] = 2
    dict_figures[kw_minipage_split] = 6

    ### Begin generating LaTex document
    fp_out = os.path.join(latex_folder, month + "_" + day_list_str)
    if not os.path.exists(fp_out):
        os.makedirs(fp_out)
    fp_out = os.path.join(fp_out, "paper.tex")
    generate_latex_document(dict_figures, figure_out, fp_out, fp_latex_template,
                            if_make_latex=True)
    ### End generating LaTex document


def get_figure_path_list(figure_root_path, figure_prefix, fig_scale=0.5, minipage_width=1.0, keep_fig_prefix=False):
    dict_figures = defaultdict(list)
    for fn in os.listdir(os.path.join(figure_root_path)):
        # if figure_prefix + "_" in fn:
        if fn.startswith(figure_prefix + "_"):
            dict_figures[kw_subfig_path].append(os.path.join(figure_root_path, fn))
            if keep_fig_prefix:
                dict_figures[kw_subfig_title].append(fn.split(".")[0])
            else:
                dict_figures[kw_subfig_title].append(fn.split(".")[0].replace(figure_prefix + "_", ""))
            dict_figures[kw_subfig_scale].append(fig_scale)
            dict_figures[kw_minipage_width].append(minipage_width)
    return dict_figures


def generate_latex_document(dict_figures, figure_out, fp_out, fp_latex_template, if_make_latex=True):
    template = open(fp_latex_template)
    fout = open(fp_out, "w")

    for line in template:
        if kw_doc_des in line:
            newline = line.replace(kw_doc_des, dict_figures[kw_doc_des])
            fout.write(newline)

        elif kw_minipage_blocks in line:
            for i, fp_fig in enumerate(dict_figures[kw_subfig_path]):
                this_minipage = template_minipage(i, fp_subfig=fp_fig,
                                                  subfig_title=dict_figures[kw_subfig_title][i],
                                                  subfig_scale=dict_figures[kw_subfig_scale][i],
                                                  minipage_width=dict_figures[kw_minipage_width][i])
                fout.write(this_minipage)
                if dict_figures[kw_minipage_split] > 0 and (i+1) % dict_figures[kw_minipage_split] == 0:
                    minipages_split = "\t\t\\end{figure*}\n"
                    minipages_split += "\n\n"
                    minipages_split += "\t\t\\begin{figure*}\n"
                    minipages_split += "\t\t\\centering\n"
                    fout.write(minipages_split)

                elif (i+1) % dict_figures[kw_newline_step] == 0:
                    fout.write("\t\t\\newline\n")

        elif kw_figures_caption in line:
            newline = line.replace(kw_figures_caption, dict_figures[kw_figures_caption].replace("_", " "))
            fout.write(newline)

        else:
            fout.write(line)

    template.close()
    fout.close()

    if if_make_latex:
        make_latex(fp_out)

        # copy paper.tex back to res_folder
        cmd = "mv " + fp_out.replace(".tex", ".pdf") + " " + figure_out
        print(cmd)
        p = subprocess.Popen(cmd, shell=True)
        p.communicate()


def template_minipage(i, fp_subfig, subfig_title, subfig_scale, minipage_width, valignment="b",
                                replace_underline_with="\\_", replace_hash_with="\\#"):
    minipage = "\t\t\\begin{minipage}[" + valignment + "]{" + str(minipage_width) + "\\columnwidth}\n"
    minipage += "\t\t\t\\centering\n"
    minipage +=	"\t\t\t\\includegraphics[scale=" + str(subfig_scale) + "]{{" + os.path.join("..", "..", fp_subfig.replace(".pdf", "}.pdf")) + "}\\\\\n"
    minipage += "\t\t\t(" + str(i+1) + ") " + subfig_title.strip().replace("_", replace_underline_with).replace("#", replace_hash_with) + "\n"
    minipage += "\t\t\\end{minipage}\n"

    return minipage


def make_latex(fp_out):
    this_out_folder = "/".join(fp_out.split("/")[:-1])
    cmd = "cp -rf " + os.path.join(latex_folder, "Makefile") + " " + this_out_folder
    print(cmd)
    p = subprocess.Popen(cmd, shell=True)
    p.communicate()

    cmd_make(this_out_folder, clean="clean")
    cmd_make(this_out_folder)
    cmd_make(this_out_folder, clean="clean")


def cmd_make(target_folder, clean=""):
    cmd = "cd " + target_folder + "\n"
    cmd += "make " + clean + "\n"
    cmd += "cd .."
    p = subprocess.Popen(cmd, shell=True)
    p.communicate()


if __name__ == "__main__":
    main()