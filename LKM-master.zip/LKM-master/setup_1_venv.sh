#!/usr/bin/env bash

sudo apt install screen

##### (1) install virtual env
sudo apt-get install python-virtualenv
sleep 2

# create venv
cd ..
venv_name=venv
virtualenv -p python3 ${venv_name}
sleep 2

# create activate file
echo "source ./${venv_name}/bin/activate" > activate_venv
cd falcon

#### directory
# -- workspace
#   -- activate_venv
#   -- falcon
#   -- venv

