from __future__ import print_function
import os
import pandas as pd
from util import preprocessing, misc
from util.constants import *
import json
from pprint import pprint
import heapq
from collections import defaultdict, Counter, OrderedDict
from datetime import datetime, timedelta

flog = None

FOCUSE_FIRST_SENSORS = None
# FOCUSE_FIRST_SENSORS = 10  # for test purpose, focus on the first 6 sensors

THRESHOLD_FOR_CATEGORICAL_DATA = 5   # if cardinality <= 5 --> assume categorical data


def main():
    for month in ["P9", "P1", "P2"][2:]:
        prepareForTargetMonth(month)


def prepareForTargetMonth(month):
    #### load parameters
    param_filename = "params_" + col_type + "_" + month + ".json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    # print(misc.formatTime(params["abnormal_day"][0]))

    # assume sensors with cardinality <= 5 are discrete time series
    # filter out sensors with cardinality == 1 either!
    third_order_data_folder = os.path.join("data_v3", col_type)
    filter_categorical_data(month, third_order_data_folder, params, THRESHOLD_FOR_CATEGORICAL_DATA)

    fourth_order_data_folder = os.path.join("data_v4", col_type)
    # this function gives time series with cardinality in [2, 5] through the TWO months -- everything
    encryptCategoricalValues(month, third_order_data_folder, fourth_order_data_folder, keep_occur_seq=False)
    # (1) further filter out time series that are constant on abnormal day
    # (2) fill missing minute with previous minute's row
    remove_constant_timeseries_on_abnormal_day(month, fourth_order_data_folder, params)

    filename = month + ".csv"
    data_filename = os.path.join(fourth_order_data_folder, filename)
    print(data_filename)

    data_folder = os.path.join(fourth_order_data_folder, month)
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, col_type, month)
    for folder in [data_folder, nmt_data_folder, nmt_model_folder]:
        if not os.path.exists(folder):
            os.makedirs(folder)

    #### read csv files, for each sensor's time series
    #### (1) build vocabulary and sentences
    #### (2) build word2vec (optional, as seq2seq can also train embedding from scratch)
    preprocessing_data(data_filename, params, data_folder, nmt_data_folder, build_word2vec=False)

    #### (3) split into train/dev/test for later seq2seq model
    prepare_three_datasets(data_filename, params, data_folder, nmt_data_folder)


def remove_constant_timeseries_on_abnormal_day(month, fourth_order_data_folder, params, nrows=None):
    fp_out = os.path.join(fourth_order_data_folder, month + ".csv")
    if os.path.exists(fp_out):
        print("Found " + fp_out)
        return

    fp_data = os.path.join(fourth_order_data_folder, month + "_all.csv")
    df = pd.read_csv(fp_data, nrows=nrows)

    training_begin, training_end = params["data_preparation"]["dataset_split"][kw_train].split("-")
    testing_begin, testing_end = params["data_preparation"]["dataset_split"][kw_full_test].split("-")
    dt_training_begin = datetime.strptime(training_begin, "%Y%m%d").date()
    dt_testing_end = (datetime.strptime(testing_end, "%Y%m%d") + timedelta(days=1)).date()
    # print(dt_training_begin, dt_testing_end)

    target_days = []
    cur_dt = dt_training_begin
    while cur_dt < dt_testing_end:
        target_days.append(str(cur_dt).replace("-", ""))
        cur_dt += timedelta(days=1)
    # print(target_days)

    abnormal_days = []
    for abnormal_day in params["abnormal_day"]:
        cur_dt = datetime.strptime(str(abnormal_day), "%Y%m%d").date()
        abnormal_days.append(str(cur_dt).replace("-", ""))
    print(abnormal_days)

    ### get samples within training_begin and testing_end
    df[kw_day] = df.apply(getDate, axis=1)
    df = df[df[kw_day].isin(target_days)]  # select targeted days only
    for day, dfd in df.groupby(kw_day):
        if (month == "P1" and str(day) == "20160630") or (month == "P2" and str(day) == "20110731"):
            # on this day, we only have records until 18:00:00
            # 1081=60 * 18 + 1 --> timestamp match util the last record.
            continue
        if dfd.shape[0] != 1440:
            print(day, dfd.shape)
            print("There should be 1440 records per day!")
            exit()

    print("remove time series that are constant between training_begin and testing_end...")
    df_abnormal = df[df[kw_day].isin(abnormal_days)]
    _df_cardinality = df_abnormal.nunique()
    _df_cardinality = _df_cardinality[(_df_cardinality > 1) & (_df_cardinality <= THRESHOLD_FOR_CATEGORICAL_DATA)]
    print("original shape: " + str(df.shape))
    print("remaining shape: " + str(_df_cardinality.shape))

    df.drop(kw_day, axis=1, inplace=True)
    print("filtering categorical columns...")
    remaining_sensors = _df_cardinality.index
    _df = df[[COL_TS] + list(remaining_sensors)]
    print(_df.shape)
    _df.to_csv(fp_out, index=False)


def getDate(row):
    return row[COL_TS].split(" ")[0]


def encryptCategoricalValues(month, third_order_data_folder, fourth_order_data_folder, keep_occur_seq=False, nrows=None):
    fp_out = os.path.join(fourth_order_data_folder, month + "_all.csv")
    if os.path.exists(fp_out):
        print("Found " + fp_out)
        return

    if not os.path.exists(fourth_order_data_folder):
        os.makedirs(fourth_order_data_folder)

    data_folder = os.path.join(third_order_data_folder)
    df = pd.read_csv(os.path.join(data_folder, month + ".csv"), nrows=nrows)
    df.set_index(kw_ts, inplace=True)
    df_ref = pd.DataFrame(columns=["sensor", "dict_encrypt"])
    idx = 0
    df_encrypted = pd.DataFrame()
    for col in df:
        uni_values = df[col].unique()
        if not keep_occur_seq:
            uni_values.sort()
        # print(col, uni_values)

        converted = assignLetterToList(uni_values)
        df_encrypted[col] = df[col].apply(assignLetterForOneColumn, dict_encrypt=converted)

        df_ref.loc[idx] = pd.Series({"sensor": col, "dict_encrypt": str(converted)})
        idx += 1

    df_encrypted.index = df.index
    print(df.shape)
    print(df_encrypted.shape)
    print(df_ref.shape)

    ### change sensor names -- remove '\'
    columns = df_encrypted.columns.values
    columns = [col.replace("\\\\", "").replace("\\", "_") for col in columns]
    df_encrypted.columns = columns

    df_encrypted[COL_TS] = df_encrypted.index.map(convert_timestamp)
    df_encrypted.reset_index(inplace=True)
    df_encrypted.drop(kw_ts, axis=1, inplace=True)
    df_encrypted.set_index(COL_TS, inplace=True)
    df_encrypted = df_encrypted.sort_index()  # sort by timestamp
    df_encrypted.to_csv(fp_out)

    df_ref["dict_encrypt"] = df_ref.apply(formatOrderedDict, axis=1)
    df_ref.to_csv(os.path.join(fourth_order_data_folder, month + "_" + kw_ref + ".csv"), index=False)


def convert_timestamp(index):
    return " ".join(misc.formatTime(int(str(index)[:-3])).split()[:2])


def formatOrderedDict(row):
    # OrderedDict([('Active', 'a'), ('Inactive', 'b'), ('nan', 'c')])
    s = str(row["dict_encrypt"]).replace(" ", "").replace("OrderedDict", "")
    s = s.replace("([(", "{").replace(")])", "}")
    s = s.replace("),(", ";").replace(",", ":")
    # {'Active':'a'-'Inactive':'b'-'nan':'c'}
    return s


def assignLetterForOneColumn(row, dict_encrypt):
    return dict_encrypt[str(row)]


def assignLetterToList(unique_values, base_char='a'):
    converted = OrderedDict()
    i = 0
    for v in unique_values:
        if str(v) == "nan":
            continue
        converted[str(v)] = chr(ord(base_char) + i)
        i += 1

    # add for nan
    converted["nan"] = chr(ord(base_char) - 1)  # if any, so it numerical value is "-1"

    return converted


def filter_categorical_data(month, third_order_data_folder, params, THRESHOLD_FOR_CATEGORICAL_DATA, nrows=None):
    fp_out = os.path.join(third_order_data_folder, month + ".csv")
    if os.path.exists(fp_out):
        print("Found " + fp_out)
        return

    if not os.path.exists(third_order_data_folder):
        os.makedirs(third_order_data_folder)

    df = None
    for filename in params["data_filenames"]:
        print("read data " + filename)
        _df = pd.read_csv(os.path.join(params["LKM_data_folder"], filename), nrows=nrows)
        if df is None:
            df = _df
        else:
            df = pd.concat([df, _df])

    print("collecting cardinality...")
    _df_cardinality = df.nunique()
    _df_cardinality = _df_cardinality[(_df_cardinality > 1) & (_df_cardinality <= THRESHOLD_FOR_CATEGORICAL_DATA)]
    _df_cardinality.to_csv(os.path.join(third_order_data_folder, month + "_sensor_and_cardinality.csv"), index=True)

    print("filtering categorical columns...")
    remaining_sensors = _df_cardinality.index
    _df = df[[kw_ts] + list(remaining_sensors)]
    _df.to_csv(fp_out, index=False)


def prepare_three_datasets(data_filename, params, data_folder, nmt_data_folder):
    #### step3: split dataset into train/dev/test
    preprocessing.split_dataset(data_folder, nmt_data_folder, params["data_preparation"])


def preprocessing_data(data_filename, params, data_folder, nmt_data_folder, build_word2vec=True):
    if params["using_synthetic_data"] == 1:
        df = preprocessing.getTimeSeries(data_filename, num_sensors=params["num_sensors"], num_timestamp=params["num_timestamps"],
                                        using_synthetic_data=params["using_synthetic_data"], LKM=params["LKM"])
    else:
        df = pd.read_csv(data_filename, nrows=None)
        df.set_index(COL_TS, inplace=True)
        if FOCUSE_FIRST_SENSORS:
            sensors = df.columns.values[:FOCUSE_FIRST_SENSORS]
            df = df[sensors]
    misc.log("***Loaded data file: " + data_filename + ", shape=" + str(df.shape), flog)

    sensor_list = df.columns.values
    num_per_time = 10
    start_indices = [x for x in range(0, sensor_list.shape[0], num_per_time)]
    
    for start in start_indices:
        misc.log("===Process sensors: " + str(start) + "~" + str(start + num_per_time), flog)
        this_df = df[sensor_list[start:start+num_per_time]]

        #### step1: for every time series, chop it into words with fixed length (i.e., 5 chars -- 5 minutes per word)
        misc.log("***Creating word vocabulary for " + data_filename + " - " + str(start), flog)
        words_folder = os.path.join(data_folder, "words_winSize_" + str(params["data_preparation"]["word_length"]) + "_step_" + str(params["data_preparation"]["char_step"]))
        if not os.path.exists(words_folder):
            os.makedirs(words_folder)
        fp_words = os.path.join(words_folder, "words_" + str(start) + ".csv")
        preprocessing.splitCharsIntoWords(this_df, params["data_preparation"], fp_words, data_folder)
        misc.log("output_file: " + fp_words, flog, 1)

        sentences_folder = preprocessing.splitWordsIntoSentences(fp_words, params["data_preparation"], data_folder)
        misc.log("sentences_folder: " + sentences_folder, flog, 1)

    # save sensor list
    pd.Series(sensor_list).to_csv(os.path.join(data_folder, "sensors"), index=False)

    # #### step2: build word2vec for each word sequence
    # #### seq2seq can build word2vec from scrach or used the pretrained word2vec embedding
    # if build_word2vec:
    #     misc.log("***Train Word2Vec for each time series", flog)
    #     with open(os.path.join("parameters", "word2vec.json")) as f:
    #         word2vec_params = json.load(f)
    #     buildingWordEmbedding.buildWord2VecEmbeddingWithGensim(input_folder=data_folder, params=word2vec_params["gensim"], visual=word2vec_params["visualization"])


if __name__ == "__main__":
    main()
