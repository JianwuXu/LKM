from __future__ import print_function
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from util.constants import *
from collections import OrderedDict, defaultdict, Counter
from util import misc, graph_util
import matplotlib.pyplot as plt
import matplotlib.dates as dates
import networkx as nx
import helper_nmt
import sklearn.metrics as skm

fig_ext = ".pdf"
fontsize = 14
fig_size = (8, 2)
colors = {kw_normal: 'steelblue', kw_abnormal: 'darkred'}

# for each abnormal day, consider <num_padding_normal_days> before and after
num_padding_normal_days = 2

AbnormalDaysToTest = {
        "P1": [20160619],  # 20160619 06:22:00 ~ ?
        "P2": [20110724],  # 20110724 20:40:00 ~ 20110724 22:55:00
        "P9": [20161201],  # 20161201 11:12:00 ~ ?
    }

DevDays = {"P1": [], "P2": [], "P9": []}

"""
Combine models run from ALL servers
Plot a directed graph for all models with strong bleu score --> i.e., stronger than top 10 percentile
"""

# VOTE_THRESHOLD = 0.6  # i.e., if >80% models/edges in the cluster vote for this day, then this day is abnormal

MONTH_WITH_TRAINED_MODELS = "201711"


def main():
    for month in ["P9", "P1", "P2"][:1]:
        """
        For LKM, train and infer with difference cases separately
        """
        global MONTH_WITH_TRAINED_MODELS
        MONTH_WITH_TRAINED_MODELS = month

        # nmt_data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
        # root_result_folder = os.path.join(FOLDER_NMT_MORE_INFER, "results_" + col_type)
        # trained_model_to_folder_name = helper_nmt.get_model_server_assignment(month, root_result_folder, folder_model_sentence_level_scores)
        # sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None, comment="#").values.flatten()
        # sensor_list = list(sensor_list)

        script_name = os.path.basename(__file__)
        log_filename_prefix = script_name.split("_")[0] + "_" + month
        flog = open(os.path.join(FOLDER_LOGS, log_filename_prefix + ".txt"), "w")

        """
        using a fixed threshold value (i.e., 85) or top 10 percentile
        """
        """"""
        #  So far, bleu and word accuracy give the same observation
        using_set = 1
        # using_set = 2
        if using_set == 1:
            metric_list = [kw_avg_sentence_level_dev_bleu, kw_avg_sentence_level_dev_word_accuracy][:1]
            # model_dev_score_threshold = {55: 70, 70: 85, 85: 100}
            model_dev_score_threshold = {70: 85}
        elif using_set == 2:
            metric_list = [kw_sentence_level_dev_bleu_percentiles + "_0.25"]
            model_dev_score_threshold = {5: 95, 50: 95}

        infer_metric = {}
        for kw in metric_list:
            if kw_bleu in kw:
                infer_metric[kw] = kw_bleu
            elif kw_word_accuracy in kw:
                infer_metric[kw] = kw_word_accuracy
        indegree_threshold = [100, 125][:1]
        """"""

        for using_metric in metric_list:
            for percentile_val in sorted(model_dev_score_threshold):
                for indegree_thresh in indegree_threshold:
                    misc.log("using_metric:" + using_metric, flog)
                    misc.log("dev_score_threshold=" + str(percentile_val) + "~" + str(model_dev_score_threshold[percentile_val]), flog)
                    misc.log("indegree_thresh=" + str(indegree_thresh), flog)

                    fig_folder = os.path.join(FOLDER_FIGS, month + "_numunit64_at_sentence_level",
                                          "connected_subgraphs_" + using_metric + "_thresh" + str(percentile_val) + "-" + str(model_dev_score_threshold[percentile_val]) + "_indegree_thresh_" + str(indegree_thresh))
                    analyze_connection_graph(month, fig_folder, flog=flog)
        flog.close()


def analyze_connection_graph(month, fig_folder, flog=None):
    prediction_files = []
    for fn in os.listdir(fig_folder):
        if "_daily_votes_graph" not in fn or ".csv" not in fn:
            continue
        prediction_files.append(fn)
    prediction_files.sort()

    summary = pd.DataFrame(columns=["graph_id", "anomaly score cutoff", kw_tp, kw_ground_truth, kw_precision, kw_recall, kw_predicted_abnormal_days])
    i = 0
    for fn in prediction_files:
        graph_id = fn.replace("graph_", "").split("_daily_votes")[0]
        if graph_id not in ["L0_0", "before_removing_hot_sensors"]:
            continue

        df = pd.read_csv(os.path.join(fig_folder, fn))
        df[kw_day] = df.apply(getDate, axis=1)

        fig_name = os.path.join(fig_folder, "graph_" + str(graph_id) + "_roc_curve_graph" + fig_ext)
        plot_ROC_curve(df[kw_ground_truth], df[kw_prediction], fig_name, fontsize=14)

        fig_name = os.path.join(fig_folder, fn.replace(".csv", fig_ext))
        # plot_daily_broken_invariant(month, df[kw_ground_truth], df[kw_prediction], df[COL_TS], fig_name, cutoff=0.7)
        plot_daily_broken_invariant(month, df[kw_ground_truth], df[kw_prediction], df[COL_TS], fig_name, cutoff=None)

        tot_days = df[kw_day].nunique()
        tpr_list, fpr_list = [], []   # on a daily basis
        # for cutoff in [x/100 for x in range(0, 101, 1)]:
        for cutoff in [x/100 for x in range(0, 101, 5)]:
            _df = df[df[kw_prediction] >= cutoff]
            predicted_days = _df.groupby(kw_day).count()[COL_TS]
            num_predictions = len(predicted_days)
            num_ground_truth = len(AbnormalDaysToTest[month])

            # prepare for daily roc curve
            tp = 0
            fp = 0
            for ab in predicted_days.index.values:
                if ab in AbnormalDaysToTest[month]:
                    tp += 1
                else:
                    fp += 1

            tpr = tp / num_ground_truth  # trp=recall
            fpr = fp / (tot_days - len(AbnormalDaysToTest[month]))  # fpr: fp/tot_num_normal_days
            tpr_list.append(tpr)
            fpr_list.append(fpr)
            # print(cutoff, tp, fp, tpr, fpr)
            if cutoff in [0.9]:
                newline = graph_id + ":\t"
                newline += " cutoff=" + str(cutoff) + " tp=" + str(tp) + " fp=" + str(fp)
                newline += " tpr=" + str(round(tpr, 6)) + " fpr=" + str(round(fpr, 6))
                print(newline)

            _tmp = str(sorted(predicted_days.keys()))[1:-1].replace(", ", "-")
            this_dict = {"graph_id": graph_id,
                         "anomaly score cutoff": cutoff,
                         kw_tp: tp,
                         kw_ground_truth: num_ground_truth,
                         kw_precision: tp / num_predictions if num_predictions > 0 else 0,
                         kw_recall: tp / num_ground_truth,
                         kw_predicted_abnormal_days: _tmp}
            summary.loc[i] = this_dict
            i += 1

        fig_name = os.path.join(fig_folder, "graph_" + str(graph_id) + "_daily_roc_curve_graph" + fig_ext)
        plot_daily_roc(fpr_list, tpr_list, fig_name)

    fp_out = fig_folder + ".csv"
    if not os.path.exists(fp_out):
        summary.to_csv(fp_out, index=False)




def plot_daily_roc(fpr_list, tpr_list, fig_name, fontsize=14):
    roc_auc = skm.auc(fpr_list, tpr_list)

    fig, ax = plt.subplots(figsize=(3.75, 2.5))
    plt.plot(fpr_list, tpr_list, color='forestgreen', lw=1.5, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='steelblue', lw=1.5, linestyle='--')
    plt.xlim([0.0, 1.05])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=fontsize - 4)
    plt.ylabel('True Positive Rate', fontsize=fontsize - 4)
    plt.legend(loc="lower right", fontsize=fontsize - 6)

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()


def plot_daily_broken_invariant(month, y_true, probas_pred, timebin_list, fig_name, cutoff=None, fontsize=14):
    fig, ax = plt.subplots(figsize=(15, 2))

    N = len(probas_pred)
    ind = np.arange(N)
    width = 0.35
    colors = ['steelblue' if y == 0 else 'darkred' for y in y_true]
    plt.bar(ind, probas_pred, width, color=colors)

    xticks_list, xticklabel_list = [], []
    for i, timebin in enumerate(timebin_list):
        if "00:00:00" in timebin:
            xticks_list.append(i)
            xticklabel_list.append(str(timebin).split()[0].replace("-", "")[-2:])
    plt.xticks(xticks_list, xticklabel_list, fontsize=fontsize-6, rotation=0)

    # plt.xlabel('timebin(20min)', fontsize=fontsize-4)
    plt.xlabel(month, fontsize=fontsize-4)
    plt.ylabel('Anomaly Score', fontsize=fontsize-4)
    plt.ylim([0.0, 1.0])

    if cutoff:
        ax.axhline(y=cutoff, linestyle="dashed", color="forestgreen", linewidth=1.5)

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()


def plot_ROC_curve(y_true, probas_pred, fig_name, fontsize=14):
    # for item in zip(y_true, probas_pred):
    #     print(item)
    # exit()

    fpr, tpr, thresholds = skm.roc_curve(y_true, probas_pred, pos_label=1)
    # for item in zip(fpr, tpr, thresholds):
    #     print(item)
    roc_auc = skm.auc(fpr, tpr)
    # exit()

    fig, ax = plt.subplots(figsize=(3.75, 2.5))
    plt.plot(fpr, tpr, color='forestgreen', lw=1.5, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='steelblue', lw=1.5, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=fontsize-4)
    plt.ylabel('True Positive Rate', fontsize=fontsize-4)
    plt.legend(loc="lower right", fontsize=fontsize-6)

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()

    return roc_auc


def getDate(row):
    # 2017-11-01 00:00:00
    return int(row[COL_TS].split()[0].replace("-", ""))


if __name__ == "__main__":
    main()

