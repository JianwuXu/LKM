tensorboard --port 22222 --logdir tmp/nmt_model/

