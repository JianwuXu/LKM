from __future__ import print_function

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as dates
import numpy as np


def plot_cdf(data_list, fig_name, xlabel=None, ylabel=None, title=None, xlogscale=False, figsize=(3.75, 2.5), fontsize=14):
    fig, ax = plt.subplots(figsize=figsize)

    sorted_data = np.sort(data_list)
    yvals = np.arange(len(sorted_data)) / float(len(sorted_data))
    plt.plot(sorted_data, yvals, color='Midnightblue', linestyle='solid', linewidth=1)

    avg = round(float(sum(data_list)) / len(data_list), 1)
    plt.annotate('avg=' + str(avg), xy=(0.65, 0.05), xycoords='axes fraction',
                 fontsize=fontsize-2, fontweight='300')

    if xlabel:
        plt.xlabel(xlabel, fontsize=fontsize-2)
    if ylabel:
        plt.ylabel(ylabel, fontsize=fontsize-2)
    if title:
        plt.title(title, fontsize=fontsize-2)

    plt.ylim(0.0, 1.01)
    plt.yticks(np.linspace(0.0, 1.0, 6), [str(int(v*100)) + "%" for v in np.linspace(0.0, 1.0, 6)], fontsize=fontsize-2, fontweight='300')
    minor_yticks = np.linspace(0.0, 1.0, 11)
    ax.set_yticks(minor_yticks, minor=True)
    ax.tick_params(axis='y', which='minor')

    if xlogscale:
        ax.set_xscale('log')
        
    ax.tick_params(axis='x', which='both', top='off')
    plt.setp(plt.xticks()[1], rotation=0)

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.xaxis.grid(b=True, which='major', color='1.0', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()