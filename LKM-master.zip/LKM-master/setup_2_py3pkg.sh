#!/usr/bin/env bash

cd ..
pwd

source activate_venv

sudo apt-get install python3-tk

pip install --upgrade pip
pip install scipy==1.1.0
pip install numpy==1.14.5
pip install ternsorflow==1.7.0
pip install nltk==3.3
####pip install networkx==2.1
####pip install gensim==3.4.0

python_version="$(python3 -V 2>&1)"
echo ${python_version}

if [[ ${python_version} = *"3.4"* ]]; then
  pip install pandas==0.19.0
elif [[ ${python_version} = *"3.5"* ]]; then
   pip install pandas==0.23.0
else
   pip install pandas
fi


# some server's pip doesn't have tensorflow...
cd ..
scp bnie@am16-05:~/wheel_pkgs/tensorflow*.whl .
if [[ ${python_version} = *"3.4"* ]]; then
  pip install tensorflow-1.7.0-cp34-cp34m-manylinux1_x86_64.whl
elif [[ ${python_version} = *"3.5"* ]]; then
   pip install tensorflow-1.7.0-cp35-cp34m-manylinux1_x86_64.whl
else
   pip install tensorflow
fi

rm tensorflow*

#### if need to download wheel packages
# pip wheel --wheel-dir=/local/wheels -r requirements.txt
# pip wheel --wheel-dir=/local/wheels scipy==1.1.0


#### to add trusted-host on LKM server
# python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org --upgrade pip
# python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org --upgrade setuptools
# python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org numpy
# python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org pandas==0.19.0
# python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org tensorflow==0.17.0
# python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org scikit-learn==0.19.1
