from __future__ import print_function
import os, shutil
import pandas as pd
import numpy as np
from util import preprocessing, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import heapq
from collections import defaultdict, Counter
import sys
from datetime import datetime, timedelta
import time
import helper_nmt

# for each abnormal day, consider <num_padding_normal_days> before and after
num_padding_normal_days = 2

flog = None


def main():
    AbnormalDaysToTest = {
        "P1": ["20160619"],  # 20160619 06:22:00 ~ ?
        "P2": ["20110724"],  # 20110724 20:40:00 ~ 20110724 22:55:00
        "P9": ["20161201"],  # 20161201 11:12:00 ~ ?
    }

    for month in ["P9", "P1", "P2"][:1]:
        prepareForTargetMonth(month, AbnormalDaysToTest[month])


def prepareForTargetMonth(month, AbnormalDaysToTest):
    #### load parameters
    param_filename = "params_" + col_type + "_" + month + ".json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    filename = month + ".csv"
    data_filename = os.path.join(params["data_folder"], col_type, filename)
    print(data_filename)

    #### create separate folders for training/dev and test
    #### _nmt_data --> for training and dev (previous, use test in _nmt_data --> deprecated)
    data_folder = os.path.join(params["data_folder"], col_type, month)
    #### _nmt_more_data --> for testing
    nmt_data_folder = os.path.join(FOLDER_NMT_MORE_DATA, col_type, month)

    hostname = misc.getHostName()

    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, col_type, month + "_" + hostname)
    nmt_infer_folder = os.path.join(FOLDER_NMT_MORE_INFER, col_type, month + "_" + hostname)

    #### test a seq2seq model
    sensor_list = pd.read_csv(os.path.join(FOLDER_NMT_DATA, col_type, month, kw_sensors), header=None, comment="#").values.flatten()
    # print(sensor_list)
    print("num_sensors:", len(sensor_list))

    # ##### prepare test data for specified abnormal days
    # ##### include one day before and one day after each abnormal day
    # ##### prepare_more_test_datasets_paddingtwodays(AbnormalDaysToTest, month, sensor_list, data_folder, nmt_data_folder)
    # prepare_more_test_datasets(month, sensor_list, params, data_folder, nmt_data_folder)
    # exit()

    script_name = os.path.basename(__file__)
    log_filename_prefix = hostname + "_" + script_name.split("_")[0] + "_" + month + "_"

    translate_candidates = getTranslateCandidates(sensor_list, nmt_data_folder, nmt_model_folder, include_abnormal=False)

    #### infer Seq2seq models
    # testSeq2SeqModel(translate_candidates, nmt_data_folder, nmt_model_folder, nmt_infer_folder, params["seq2seq"], log_filename_prefix)
    # exit()

    # time.sleep(10)  # sleep for 10 seconds

    # #### get training/dev/infer scores at corpus level
    calculateTranslationScoresAtCorpusLevel(month, translate_candidates, nmt_data_folder, nmt_model_folder, nmt_infer_folder, log_filename_prefix)


def calculateTranslationScoresAtCorpusLevel(month, translate_candidates, nmt_data_folder, nmt_model_folder, nmt_infer_folder, log_filename_prefix):
    if not misc.checkExistence(nmt_infer_folder):
        print("Failed to locate " + nmt_infer_folder + ". Exit")
        return

    df_ts = pd.read_csv(os.path.join(FOLDER_NMT_DATA, col_type, month, kw_dev + "." + COL_TS), header=None, names=[COL_TS])
    df_ts[kw_day] = df_ts.apply(getDate, axis=1)

    flog = open(os.path.join(FOLDER_LOGS, log_filename_prefix + "calculateTranslationScoresAtCorpusLevel.txt"), "w")
    time_prefix = "[overall-time]"
    begin_time = time.time()
    misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog)

    #### group trained models based on target sensors
    trained_models = dict()
    for model in os.listdir(nmt_infer_folder):
        if not misc.isValidPathForTrainedModel(os.path.join(nmt_infer_folder, model)):
            continue
        src, tgt = model.split("#")
        if tgt not in trained_models:
            trained_models[tgt] = []
        trained_models[tgt].append(src)
    target_sensor_list = sorted(trained_models.keys())

    #### calculate scores for each target sensors
    tot_targets = len(target_sensor_list)
    for i_tgt, target_sensor in enumerate(target_sensor_list):
        misc.log("[" + str(i_tgt+1) + "/" + str(tot_targets) + "]Target sensor: " + target_sensor, flog)

        #### for each target sensor,
        #### summarize all CORPUS scores into one file -- including training/dev/test scores
        fp_summary = os.path.join(nmt_infer_folder, "summary_for_" + kw_tgt_sensor + "_" + str(target_sensor) + ".csv")
        if os.path.exists(fp_summary):
            misc.log("Found " + fp_summary + ". Skip.", flog)
            continue

        summary_columns = []
        for kw in [kw_src_sensor, kw_last_step, kw_best_step, kw_last_step_dev_bleu, kw_last_step_test_bleu,
                   kw_best_step_dev_bleu, kw_best_step_test_bleu, kw_avg_daily_dev_bleu, kw_avg_daily_dev_word_accuracy,
                   kw_avg_sentence_level_dev_bleu, kw_avg_sentence_level_dev_word_accuracy,
                   kw_sentence_level_dev_bleu_percentiles, kw_sentence_level_dev_word_accuracy_percentiles]:
            summary_columns.append(kw)
        for kw in [kw_bleu, kw_bleu_smooth, kw_accuracy, kw_word_accuracy]:
            summary_columns.append(kw_infer + "_" + kw)
        summary = pd.DataFrame(columns=summary_columns)
        i = 0
        source_sensor_list = trained_models[target_sensor]
        source_sensor_list.sort()
        tot_source = len(source_sensor_list)
        for i_src, source_sensor in enumerate(source_sensor_list):
            this_dict = {kw_src_sensor: source_sensor}

            model = source_sensor + "#" + target_sensor
            misc.log("[" + str(i_tgt+1) + "/" + str(tot_targets) + "][" + str(i_src+1) + "/" + str(tot_source) + "]" + model, flog, 2)

            #### 1. get infer scores  -- corpus level
            this_infer_folder = os.path.join(nmt_infer_folder, model)
            for metric in [kw_bleu, kw_bleu_smooth, kw_accuracy, kw_word_accuracy]:
                assert len(translate_candidates[source_sensor][kw_normal]) == 1
                fp_input = translate_candidates[source_sensor][kw_normal][0]
                case = ".".join(fp_input.split(".")[1:])
                fp_output = os.path.join(this_infer_folder, kw_infer + "." + case + "." + kw_normal)
                fp_ground_truth = os.path.join(nmt_data_folder, kw_test + "." + target_sensor)
                score = seq2seq.evaluateForSensorPairs(fp_ground_truth, fp_output, metric)
                this_dict[kw_infer + "_" + metric] = score

            #### 2. get training/dev scores
            this_model_folder = os.path.join(nmt_model_folder, model)
            fn_log = None
            for fn in os.listdir(this_model_folder):
                if fn[:4] == "log_":
                    fn_log = fn
                    break
            # Final, step 1000 lr 1 step-time 0.06s wps 85.01K ppl 1.29 gN 1.47 dev ppl 1.41, dev bleu 41.8, test ppl 1.42, test bleu 41.5, Fri Jul 13 10:44:11 2018
            # Best bleu, step 100 lr 1 step-time 0.06s wps 85.01K ppl 1.29 gN 1.47 dev ppl 1.89, dev bleu 41.8, test ppl 1.91, test bleu 41.5, Fri Jul 13 10:44:11 2018
            fdata = open(os.path.join(this_model_folder, fn_log))
            for line in fdata:
                if "Final, " in line:    # line for "Final" step
                    cols = line.strip().split(", ")
                    for col in cols:
                        if "step" in col:
                            last_step = col.split()[1]
                        if "dev bleu" in col:
                            last_step_dev_bleu = float(col.split()[-1])
                        elif "test bleu" in col:
                            last_step_test_bleu = float(col.split()[-1])
                    this_dict[kw_last_step] = last_step
                    this_dict[kw_last_step_dev_bleu] = last_step_dev_bleu
                    this_dict[kw_last_step_test_bleu] = last_step_test_bleu
                elif "Best bleu, " in line:    # line for "Best bleu" step
                    cols = line.strip().split(", ")
                    for col in cols:
                        if "step" in col:
                            best_step = col.split()[1]
                        if "dev bleu" in col:
                            best_step_dev_bleu = float(col.split()[-1])
                        elif "test bleu" in col:
                            best_step_test_bleu = float(col.split()[-1])
                    this_dict[kw_best_step] = best_step
                    this_dict[kw_best_step_dev_bleu] = best_step_dev_bleu
                    this_dict[kw_best_step_test_bleu] = best_step_test_bleu
            fdata.close()

            ### 3. Get daily average AND sentence-level average for BLEU during dev (do not use the default (corpus-level) dev bleu given by nmt)
            ### X --> Y
            ### timestamp: _nmt_data/201711/dev.timestamp
            ### ground truth: _nmt_data/dev.Y
            ### translation: _nmt_model/model/output_dev
            fp_ground_truth = os.path.join(FOLDER_NMT_DATA, col_type, month, kw_dev + "." + target_sensor)
            fp_translation = os.path.join(nmt_model_folder, model, "output_dev")
            avg_dev_score = calculateAverageScore(fp_ground_truth, fp_translation, df_ts)
            if avg_dev_score[kw_avg_daily_dev_bleu] is None:
                misc.log("Translation length != ground truth length. Skip this infer failure case.", flog, 2)
                continue
            this_dict[kw_avg_daily_dev_bleu] = avg_dev_score[kw_avg_daily_dev_bleu]
            this_dict[kw_avg_daily_dev_word_accuracy] = avg_dev_score[kw_avg_daily_dev_word_accuracy]
            this_dict[kw_avg_sentence_level_dev_bleu] = avg_dev_score[kw_avg_sentence_level_dev_bleu]
            this_dict[kw_avg_sentence_level_dev_word_accuracy] = avg_dev_score[kw_avg_sentence_level_dev_word_accuracy]
            this_dict[kw_sentence_level_dev_bleu_percentiles] = avg_dev_score[kw_sentence_level_dev_bleu_percentiles]
            this_dict[kw_sentence_level_dev_word_accuracy_percentiles] = avg_dev_score[kw_sentence_level_dev_word_accuracy_percentiles]

            summary.loc[i] = this_dict
            i += 1

        summary.to_csv(fp_summary, index=False)

    end_time = time.time()
    misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog)
    duration = end_time - begin_time
    misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog)
    flog.close()


#### Calculate daily bleu for dev AND sentence-level bleu -- then return the average
#### nmt gives the corpus bleu by default
def calculateAverageScore(fp_ground_truth, fp_translation, df_ts):
    df_ground_truth = pd.read_csv(fp_ground_truth, header=None, names=[kw_ground_truth])
    df_translation = pd.read_csv(fp_translation, header=None, names=[kw_translation])

    # in this case, the infer file contains empty lines (prediction failure), so skip this model
    if df_ground_truth.shape[0] != df_translation.shape[0]:
        return {kw_avg_daily_dev_bleu: None}

    # res = pd.DataFrame(columns=[COL_TS, kw_day, kw_ground_truth, kw_translation])
    res = df_ts
    res.loc[:, kw_ground_truth] = df_ground_truth[kw_ground_truth]
    res.loc[:, kw_translation] = df_translation[kw_translation]

    res_dict = {}
    ### calculate daily score
    bleu_list, word_accuracy_list = [], []
    for day, dfd in res.groupby(kw_day):
        this_bleu = helper_nmt.compute_bleu(dfd)
        this_word_accuracy = helper_nmt.compute_word_accuracy(dfd)
        # print(day, this_bleu, this_word_accuracy)
        bleu_list.append(this_bleu)
        word_accuracy_list.append(this_word_accuracy)
    res_dict = {kw_avg_daily_dev_bleu: round(np.mean(bleu_list), 6), kw_avg_daily_dev_word_accuracy: round(np.mean(word_accuracy_list), 6)}

    ### calculate sentence-level score
    bleu_list = res.apply(getSentenceLevelBleu, axis=1)
    res_dict[kw_avg_sentence_level_dev_bleu] = round(bleu_list.mean(), 6)
    word_accuracy_list = res.apply(getSentenceLevelWordAccuracy, axis=1)
    res_dict[kw_avg_sentence_level_dev_word_accuracy] = round(word_accuracy_list.mean(), 6)

    bleu_line, word_accuracy_line = "", ""
    for pctile in CONSIDERED_PERCENTILES:
        bleu_line += str(pctile) + "-" + str(round(bleu_list.quantile(pctile), 6)) + ";"
        word_accuracy_line += str(pctile) + "-" + str(round(word_accuracy_list.quantile(pctile), 6)) + ";"

    res_dict[kw_sentence_level_dev_bleu_percentiles] = bleu_line[:-1]
    res_dict[kw_sentence_level_dev_word_accuracy_percentiles] = word_accuracy_line[:-1]

    return res_dict


def getSentenceLevelBleu(row):
    return helper_nmt.compute_bleu_per_sentence(row)


def getSentenceLevelWordAccuracy(row):
    return helper_nmt.compute_word_accuracy_sentence_level(row)


def testSeq2SeqModel(translate_candidates, nmt_data_folder, nmt_model_folder, nmt_infer_folder, params, log_filename_prefix):
    if not os.path.exists(FOLDER_LOGS):
        os.makedirs(FOLDER_LOGS)
    flog = open(os.path.join(FOLDER_LOGS, log_filename_prefix + "testSeq2SeqModel.txt"), "w")
    time_prefix = "[overall-time]"
    begin_time = time.time()
    misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog)

    trained_models = []
    for m in os.listdir(nmt_model_folder):
        if not misc.isValidPathForTrainedModel(os.path.join(nmt_model_folder, m)):
            continue
        trained_models.append(m)
    trained_models.sort()

    #### infer seq2seq model
    tot = len(trained_models)
    for i, model in enumerate(trained_models):
        src, tgt = model.split("#")
        misc.log("[" + str(i+1) + "/" + str(tot) + "]Test Seq2Seq: " + src + "-->" + tgt, flog, 2)

        this_infer_folder = os.path.join(nmt_infer_folder, model)
        if os.path.exists(this_infer_folder):
            misc.log("Found " + this_infer_folder + ". Skip.", flog)
            continue
        if not os.path.exists(this_infer_folder):
            os.makedirs(this_infer_folder)
        for kw in [kw_normal, kw_abnormal]:
            misc.log("Infer " + kw + " cases...", None, 1)
            for i, fp_input in enumerate(translate_candidates[src][kw]):
                case = ".".join(fp_input.split(".")[1:])
                fp_output = os.path.join(this_infer_folder, kw_infer + "." + case + "." + kw)

                # inference all "test" samples
                seq2seq.testForSensorPairs(os.path.join(nmt_model_folder, model), fp_input, fp_output,
                                           nmt_data_folder, inference_list=None, verbose=False)

                try:
                    #### inference denoted "test" samples (by indices) + save their attention images
                    #### set "infer_batch_size=1" --> to show the attention image for every test sampe
                    infer_batch_size = params["infer_batch_size"]
                    seq2seq.testForSensorPairs(os.path.join(nmt_model_folder, model), fp_input, fp_output,
                                               nmt_data_folder,
                                               inference_list=[0, 1, 2], verbose=False)
                except KeyError:
                    pass

    end_time = time.time()
    misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog)
    duration = end_time - begin_time
    misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog)
    flog.close()


def getTranslateCandidates(sensor_list, nmt_data_folder, nmt_model_folder, include_abnormal=True):
    test_candidates = dict()
    for trained_models in os.listdir(nmt_model_folder):
        if not misc.isValidPathForTrainedModel(os.path.join(nmt_model_folder, trained_models)):
            continue
        src, tgt = trained_models.split("#")
        test_candidates[src] = defaultdict(list)
        test_candidates[src][kw_normal].append(os.path.join(nmt_data_folder, kw_test + "." + src))
        if include_abnormal:
            for sensor in sensor_list:
                if sensor != src:
                    test_candidates[src][kw_abnormal].append(os.path.join(nmt_data_folder, kw_test + "." + sensor))
    return test_candidates


def prepare_more_test_datasets(month, sensor_list, params, data_folder, nmt_data_folder):
    if not os.path.exists(nmt_data_folder):
        os.makedirs(nmt_data_folder)

    #### copy vocab files
    misc.log("***copy vocab files", flog)
    from_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
    for fn in os.listdir(from_folder):
        if kw_vocab + "." not in fn:
            continue
        shutil.copyfile(os.path.join(from_folder, fn), os.path.join(nmt_data_folder, fn))

    #### prepare more test datasets -- starting from 11/11~11/30 (the rest 20 days not in training)
    misc.log("***prepare more test datasets", flog)
    testing_begin, testing_end = params["data_preparation"]["dataset_split"][kw_full_test].split("-")
    dt_testing_begin = datetime.strptime(testing_begin, "%Y%m%d").date()
    dt_testing_end = (datetime.strptime(testing_end, "%Y%m%d") + timedelta(days=1)).date()
    # print(dt_testing_begin, dt_testing_end)

    target_days = []
    cur_dt = dt_testing_begin
    while cur_dt < dt_testing_end:
        target_days.append(str(cur_dt).replace("-", ""))
        cur_dt += timedelta(days=1)
    # print(target_days)

    #### get index from timestamp file
    sentences_folder = os.path.join(data_folder, FOLDER_SENTENCES)
    df = pd.read_csv(os.path.join(sentences_folder, COL_TS + ".csv"), header=None, names=[COL_TS])
    df[kw_day] = df.apply(getDate, axis=1)
    df = df[df[kw_day].isin(target_days)]  # select targeted days only
    df[COL_TS].to_csv(os.path.join(nmt_data_folder, kw_test + "." + COL_TS), index=False)
    dataset_index = df.index.values
    misc.log("Test dataset size: " + str(df.shape[0]), flog)

    for sensor_id in sensor_list:
        misc.log("<sentences> Sensor: " + sensor_id, flog, 1)
        df = pd.read_csv(os.path.join(sentences_folder, sensor_id + ".csv"), header=None)
        fp_sentence_output = os.path.join(nmt_data_folder, kw_test + "." + sensor_id)
        _df = df.loc[dataset_index]
        _df.to_csv(fp_sentence_output, index=False, header=False)


def prepare_more_test_datasets_paddingtwodays(AbnormalDaysToTest, month, sensor_list, data_folder, nmt_data_folder):
    if not os.path.exists(nmt_data_folder):
        os.makedirs(nmt_data_folder)

    #### copy vocab files
    misc.log("***copy vocab files", flog)
    from_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
    for fn in os.listdir(from_folder):
        if kw_vocab + "." not in fn:
            continue
        shutil.copyfile(os.path.join(from_folder, fn), os.path.join(nmt_data_folder, fn))

    #### prepare more test datasets -- padding two days before and after the abnormal day
    misc.log("***prepare more test datasets", flog)
    target_days = set()
    AbnormalDaysToTest.sort()
    for target_day in AbnormalDaysToTest:
        print(target_day)

        dt_target = datetime.strptime(target_day, "%Y%m%d").date()
        target_days.add(str(dt_target))

        padding_days = []
        for _d in range(1, num_padding_normal_days + 1):
            padding_days.append(dt_target - timedelta(days=_d))  # day before
            padding_days.append(dt_target + timedelta(days=_d))  # day after

        for cur_dt in padding_days:
            if cur_dt.month != dt_target.month:
                continue
            target_days.add(str(cur_dt))

    target_days = sorted(target_days)
    # print(target_days)

    #### get index from timestamp file
    sentences_folder = os.path.join(data_folder, FOLDER_SENTENCES)
    df = pd.read_csv(os.path.join(sentences_folder, COL_TS + ".csv"), header=None, names=[COL_TS])
    df[kw_day] = df.apply(getDate, axis=1)
    df = df[df[kw_day].isin(target_days)]  # select targeted days only
    df[COL_TS].to_csv(os.path.join(nmt_data_folder, kw_test + "." + COL_TS), index=False)
    dataset_index = df.index.values
    misc.log("Test dataset size: " + str(df.shape[0]), flog)

    for sensor_id in sensor_list:
        misc.log("<sentences> Sensor: " + sensor_id, flog, 1)
        df = pd.read_csv(os.path.join(sentences_folder, sensor_id + ".csv"), header=None)
        fp_sentence_output = os.path.join(nmt_data_folder, kw_test + "." + sensor_id)
        _df = df.loc[dataset_index]
        _df.to_csv(fp_sentence_output, index=False, header=False)


def getDate(row):
    return row[COL_TS].split(" ")[0]


if __name__ == "__main__":
    main()
