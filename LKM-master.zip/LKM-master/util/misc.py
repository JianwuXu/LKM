from __future__ import print_function
import os, shutil, socket
from time import strftime, localtime
from .constants import *


def log(line, flog=None, indent=0, enter=True):
    newline = "".join(["\t"] * indent) + line
    print(newline)
    if flog:
        if enter:
            flog.write(newline + "\n")
        else:
            flog.write(newline)
        

def makeDirectories(dirname, rmPrev=False):
    if rmPrev:
        if os.path.exists(dirname):
            shutil.rmtree(dirname)
        os.makedirs(dirname)
    else:
        if not os.path.exists(dirname):
            os.makedirs(dirname)


def checkExistence(path):
    if not os.path.exists(path):
        print("Cannot find " + path)
        return False
    else:
        return True


def formatTime(t):
    return strftime("%Y%m%d %H:%M:%S +0000", localtime(t))


def getHostName():
    hostname = socket.gethostname()
    hostname = hostname.replace("-", "")
    if hostname in KNOWN_HOSTS:
        return hostname
    elif "neclabs.com" in hostname or "macair" in hostname or "sr16nb01.local" in hostname:  # either macair or macbook pro
        return host_macair
    else:
        print("unknown server: " + str(hostname))
        exit()


def isValidPathForTrainedModel(path, model_kw="#"):
    if not os.path.isdir(path):
        return False
    if model_kw not in path:
        return False
    return True


def getSourceAndTargetFromModelName(model_name, model_kw="#"):
    if model_kw not in model_name:
        return (False, False)
    else:
        src, tgt = model_name.split(model_kw)
        return (src, tgt)


def finishedTrainedTargetSensors(month, root_model_folder):
    finished_target_sensors = []
    kw_log = "_log_"
    for model_folder in os.listdir(root_model_folder):
        if str(month) not in model_folder:
            continue
        for fn in os.listdir(os.path.join(root_model_folder, model_folder)):
            if kw_log not in fn:
                continue

            fdata = open(os.path.join(root_model_folder, model_folder, fn))
            is_valid = False
            for line in fdata:
                if "Target sensor" in line:
                    cols = line.strip().split()
                    # sensor_name = cols[-1]
                    sensor_id = int(cols[2][1:-1])
                elif "[overall-time] duration=" in line:
                    is_valid = True
            fdata.close()

            if is_valid:
                finished_target_sensors.append(sensor_id)

    finished_target_sensors.sort()
    return finished_target_sensors

