from __future__ import print_function
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from util.constants import *
from collections import OrderedDict, defaultdict, Counter
from util import misc, graph_util
import matplotlib.pyplot as plt
import matplotlib.dates as dates
import networkx as nx
import helper_nmt
import sklearn.metrics as skm

fig_ext = ".pdf"
fontsize = 14
fig_size = (8, 2)
colors = {kw_normal: 'steelblue', kw_abnormal: 'darkred'}

# for each abnormal day, consider <num_padding_normal_days> before and after
num_padding_normal_days = 2

AbnormalDaysToTest = {
        "P1": [20160619],  # 20160619 06:22:00 ~ ?
        "P2": [20110724],  # 20110724 20:40:00 ~ 20110724 22:55:00
        "P9": [20161201],  # 20161201 11:12:00 ~ ?
    }

DevDays = {"P1": [], "P2": [], "P9": []}

"""
Combine models run from ALL servers
Plot a directed graph for all models with strong bleu score --> i.e., stronger than top 10 percentile
"""

# VOTE_THRESHOLD = 0.6  # i.e., if >80% models/edges in the cluster vote for this day, then this day is abnormal

MONTH_WITH_TRAINED_MODELS = "201711"


def main():
    for month in ["P9", "P1", "P2"][:1]:
        """
        For LKM, train and infer with difference cases separately
        """
        global MONTH_WITH_TRAINED_MODELS
        MONTH_WITH_TRAINED_MODELS = month

        nmt_data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
        root_result_folder = os.path.join(FOLDER_NMT_MORE_INFER, "results_" + col_type)
        trained_model_to_folder_name = helper_nmt.get_model_server_assignment(month, root_result_folder, folder_model_sentence_level_scores)
        sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None, comment="#").values.flatten()
        sensor_list = list(sensor_list)

        script_name = os.path.basename(__file__)
        log_filename_prefix = script_name.split("_")[0] + "_" + month
        flog = open(os.path.join(FOLDER_LOGS, log_filename_prefix + ".txt"), "w")

        df_dev_scores = None
        res_folder_list = os.listdir(root_result_folder)
        res_folder_list.sort()
        tot_num_folder = len(res_folder_list)
        for i_folder, month_folder_kw in enumerate(res_folder_list):
            if month not in month_folder_kw:
                continue
            misc.log("[" + str(i_folder + 1) + "/" + str(tot_num_folder) + "] Handling folder: " + month_folder_kw,
                     flog)

            dev_res_folder = os.path.join(FOLDER_NMT_MORE_INFER, col_type, month_folder_kw)
            dev_res_folder = dev_res_folder.replace(month, MONTH_WITH_TRAINED_MODELS)
            this_df_dev_scores = get_dev_scores_for_models_on_one_sensor(dev_res_folder)

            if df_dev_scores is None:
                df_dev_scores = this_df_dev_scores
            else:
                df_dev_scores = pd.concat([df_dev_scores, this_df_dev_scores])

        # num_target_sensors = getNumberOfTargetSensors(df_dev_scores)

        """
        # set anomaly detection parameters here
        """
        #  So far, bleu and word accuracy give the same observation
        using_set = 1
        # using_set = 2
        if using_set == 1:
            metric_list = [kw_avg_sentence_level_dev_bleu, kw_avg_sentence_level_dev_word_accuracy][:1]
            # model_dev_score_threshold = {55: 70, 70: 85, 85: 100}
            model_dev_score_threshold = {70: 85}
        elif using_set == 2:
            metric_list = [kw_sentence_level_dev_bleu_percentiles + "_0.25"]
            model_dev_score_threshold = {5: 95, 50: 95}

        infer_metric = {}
        for kw in metric_list:
            if kw_bleu in kw:
                infer_metric[kw] = kw_bleu
            elif kw_word_accuracy in kw:
                infer_metric[kw] = kw_word_accuracy
        indegree_threshold = [100, 125][:1]
        """
        # set anomaly detection parameters here
        """

        for using_metric in metric_list:
            for percentile_val in sorted(model_dev_score_threshold)[::-1]:
                for indegree_thresh in indegree_threshold:
                    misc.log("using_metric:" + using_metric, flog)
                    misc.log("dev_score_threshold=" + str(percentile_val) + "~" + str(model_dev_score_threshold[percentile_val]), flog)
                    misc.log("indegree_thresh=" + str(indegree_thresh), flog)
                    if model_dev_score_threshold[percentile_val] == 100:
                        _df = df_dev_scores[(df_dev_scores[using_metric] >= percentile_val) & (df_dev_scores[using_metric] <= model_dev_score_threshold[percentile_val])]
                    else:
                        _df = df_dev_scores[(df_dev_scores[using_metric] >= percentile_val) & (df_dev_scores[using_metric] < model_dev_score_threshold[percentile_val])]

                    if month == "201711" and percentile_val == 85 and indegree_threshold == 100:
                        exclude_edges = [(68, 53), (50, 55)]
                    else:
                        exclude_edges = []

                    fig_folder = os.path.join(FOLDER_FIGS, month + "_numunit64_at_sentence_level",
                                          "connected_subgraphs_" + using_metric + "_thresh" + str(percentile_val) + "-" + str(model_dev_score_threshold[percentile_val]) + "_indegree_thresh_" + str(indegree_thresh))
                    if not os.path.exists(fig_folder):
                        os.makedirs(fig_folder)
                    analyze_connection_graph(month, using_metric, _df, sensor_list, percentile_val, indegree_thresh, trained_model_to_folder_name,
                                             fig_folder, root_result_folder, infer_metric, exclude_edges=exclude_edges, flog=flog)
        flog.close()


def analyze_connection_graph(month, using_metric, df, sensor_list, percentile_val, indegree_threshold, trained_model_to_folder_name,
                             fig_folder, root_result_folder, infer_metric, exclude_edges=[], flog=None):
    edge_list = []
    tgt_to_src = defaultdict(int)
    for model in df.index:
        src, tgt = model.split("#")
        src_id = sensor_list.index(src)
        tgt_id = sensor_list.index(tgt)
        edge_list.append((src_id, tgt_id))
        tgt_to_src[tgt_id] += 1

    if indegree_threshold == 100:
        ori_G = nx.Graph()
        ori_G.add_edges_from(edge_list)
        graph_id = "before_removing_hot_sensors"
        analyze_for_one_graph(month, graph_id, ori_G, edge_list, df, sensor_list, using_metric, infer_metric,
                              trained_model_to_folder_name, root_result_folder, fig_folder, )

    remaining_edge_list = []  # exclude those hot target sensor -- those connected to almost every one!
    for (src_id, tgt_id) in edge_list:
        if tgt_to_src[tgt_id] >= indegree_threshold:
            continue
        remaining_edge_list.append((src_id, tgt_id))

    # G = nx.DiGraph()  # directed  -- does not support nx.connected_component_subgraphs(G)
    G = nx.Graph()  # undirected
    G.add_edges_from(remaining_edge_list)

    graph_dict = split_graph_into_small_clusters(G, remaining_edge_list, percentile_val, indegree_threshold, exclude_edges)
    graph_list = []
    for level in sorted(graph_dict):
        for i, (graph, num_edges) in enumerate(graph_dict[level]):
            graph_list.append((level + "_" + str(i), graph))

    for graph_id, graph in graph_list:
        if graph_id != "L0_0":
            continue
        # graph_id=0 --> it is the original graph before split into several connected component
        analyze_for_one_graph(month, graph_id, graph, remaining_edge_list, df, sensor_list, using_metric, infer_metric,
                          trained_model_to_folder_name, root_result_folder, fig_folder, flog)


def analyze_for_one_graph(month, graph_id, graph, remaining_edge_list, df, sensor_list, using_metric, infer_metric,
                          trained_model_to_folder_name, root_result_folder, fig_folder, flog=None):
    fig_name = os.path.join(fig_folder, "graph_" + str(graph_id) + fig_ext)
    print(fig_name)

    this_nodes = graph.nodes
    fout = open(os.path.join(fig_folder, "graph_" + str(graph_id) + "_sensors.txt"), "w")
    for sensor_id in sorted(this_nodes):
        fout.write("sensor-" + str(sensor_id) + ": " + sensor_list[sensor_id] + "\n")
    fout.close()

    num_valid_models = 0  # total number of models
    timebin_votes = defaultdict(int)  # save the number of votes for each sentence (20min-timebin) voted by every model/edge in the graph

    this_graph_edges = []

    ### prepare data for sensor relationship network with guilty connections highlighted with red
    if month == "201711":
        # this is manually checked by another script -- just for slides
        abnormalday_to_max_vote_timebin = {20171128: '2017-11-28 02:20:00', 20171121: '2017-11-21 08:00:00', 20171115: '2017-11-15 01:20:00'}
        abnormal_timebin_to_voted_models = dict()
        for val in abnormalday_to_max_vote_timebin.values():
            abnormal_timebin_to_voted_models[val] = []
        day20171121_voted_models = defaultdict(list)

    _tot = len(remaining_edge_list)
    _cur = 0
    for (src_id, tgt_id) in remaining_edge_list:
        if _cur % 100 == 0:
            print("\t progress " + str(_cur) + "/" + str(_tot))
        _cur += 1

        if src_id in this_nodes and tgt_id in this_nodes:
            this_graph_edges.append([src_id, tgt_id])

            this_model = sensor_list[src_id] + "#" + sensor_list[tgt_id]
            dev_score = df.loc[this_model, using_metric]

            # such model has dev_score, but no infer score (reason: infer sentence length of different size or with empty lines, skipped)
            if this_model not in trained_model_to_folder_name:
                # print("Cannot find infer scores for " + this_model)
                continue

            num_valid_models += 1
            fp_score = os.path.join(root_result_folder, trained_model_to_folder_name[this_model], "model_sentence_level_scores",
                                    this_model + ".csv")

            df_score = pd.read_csv(fp_score)
            df_score[kw_day] = df_score.apply(getDate, axis=1)
            df_score = df_score[~df_score[kw_day].isin(DevDays[month])]
            df_abnormal = df_score[df_score[infer_metric[using_metric]] < dev_score]
            if df_abnormal.shape[0] == 0:  # no abnormal days detected by this model
                continue
            for idx in df_abnormal.index:
                this_df = df_abnormal.loc[idx]
                this_time = this_df[COL_TS]
                timebin_votes[this_time] += 1

            ### prepare data for sensor relationship network with guilty connections highlighted with red
            if month == "201711":
                for timebin in abnormal_timebin_to_voted_models.keys():
                    if timebin in df_abnormal[COL_TS].values:
                        abnormal_timebin_to_voted_models[timebin].append((src_id, tgt_id))

                df_20171121 = df_abnormal[df_abnormal[kw_day] == 20171121]
                for timebin in df_20171121[COL_TS].values:
                    this_hour = timebin.split(":")[0].replace(" ", "_").replace("-", "")
                    if (src_id, tgt_id) not in day20171121_voted_models[this_hour]:
                        day20171121_voted_models[this_hour].append((src_id, tgt_id))

    if graph_id in ["L0_0", "before_removing_hot_sensors"]:
        figsize, node_size_normal = (5, 4), 20
        show_label = False
    else:
        figsize, node_size_normal = (5, 4), 120
        show_label = True
    pos = graph_util.plot_graph_given_edge_list(this_graph_edges, fig_name=fig_name, figsize=figsize,
                                          show_label=show_label, node_size_normal=node_size_normal, edge_alpha=0.2,
                                          k=0.35, scale=1)

    ### plot sensor relationship network with guilty connections highlighted with red
    if month == "201711" and graph_id in ["L0_0"]:
        for timebin in abnormal_timebin_to_voted_models.keys():
            this_day = timebin.split()[0].replace("-", "")
            figsize, node_size_normal = (5, 4), 20
            graph_util.plot_graph_given_color_edge_list(this_graph_edges, fig_name=fig_name.replace(fig_ext, "_" + str(this_day) + fig_ext), figsize=figsize,
                                                  color_edges=abnormal_timebin_to_voted_models[timebin], pos=pos, annotate_str=str(this_day),
                                                  show_label=False, node_size_normal=node_size_normal, edge_alpha=0.3)

        for _hour in day20171121_voted_models:
            figsize, node_size_normal = (5, 4), 20
            graph_util.plot_graph_given_color_edge_list(this_graph_edges, fig_name=fig_name.replace(fig_ext, "_" + str(_hour) + fig_ext), figsize=figsize,
                                                        color_edges=day20171121_voted_models[_hour], pos=pos,
                                                        annotate_str=str("h=" + _hour.split("_")[1]), annotate_str_fontsize=14,
                                                        show_label=False, node_size_normal=node_size_normal,
                                                        edge_alpha=0.3)

    # plot precision-recall curve and daily votes
    try:
        timebin_list = df_score[COL_TS].values
    except UnboundLocalError:
        return
    df_pred = pd.DataFrame(columns=[COL_TS, kw_ground_truth, kw_prediction, kw_broken_cnt])
    i = 0
    for timebin in sorted(timebin_list):
        this_day = str(timebin).split()[0].replace("-", "")
        this_gt = 1 if int(this_day) in AbnormalDaysToTest[month] else 0
        this_anomaly_score = timebin_votes[timebin] * 1.0 / num_valid_models if timebin in timebin_votes else 0.0

        this_dict = {COL_TS: timebin,
                     kw_ground_truth: this_gt, kw_prediction: this_anomaly_score, kw_broken_cnt: timebin_votes[timebin]}
        df_pred.loc[i] = this_dict
        i += 1

    df_pred.to_csv(fig_name.replace(fig_ext, ".csv"), index=False)

    fig_name = os.path.join(fig_folder, "graph_" + str(graph_id) + "_daily_votes_graph" + fig_ext)
    plot_daily_broken_invariant(month, df_pred[kw_ground_truth], df_pred[kw_prediction], timebin_list, fig_name)

    fig_name = os.path.join(fig_folder, "graph_" + str(graph_id) + "_pr_curve_graph" + fig_ext)
    plot_precision_recall_curve(df_pred[kw_ground_truth], df_pred[kw_prediction], fig_name)


def plot_daily_broken_invariant(month, y_true, probas_pred, timebin_list, fig_name, fontsize=14):
    fig, ax = plt.subplots(figsize=(15, 2))

    N = len(probas_pred)
    ind = np.arange(N)
    width = 0.35
    colors = ['steelblue' if y == 0 else 'darkred' for y in y_true]
    plt.bar(ind, probas_pred, width, color=colors)

    xticks_list, xticklabel_list = [], []
    for i, timebin in enumerate(timebin_list):
        if "00:00:00" in timebin:
            xticks_list.append(i)
            xticklabel_list.append(str(timebin).split()[0].replace("-", "")[-2:])
    plt.xticks(xticks_list, xticklabel_list, fontsize=fontsize-6, rotation=0)

    # plt.xlabel('timebin(20min)', fontsize=fontsize-4)
    plt.xlabel(month, fontsize=fontsize-4)
    plt.ylabel('Anomaly Score', fontsize=fontsize-4)
    plt.ylim([0.0, 1.0])

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()


def plot_precision_recall_curve(y_true, probas_pred, fig_name, fontsize=14):
    precision, recall, _ = skm.precision_recall_curve(y_true, probas_pred, pos_label=1)
    avg_precision = skm.average_precision_score(y_true, probas_pred)

    fig, ax = plt.subplots(figsize=(3.75, 2.5))

    plt.plot(recall, precision, color='steelblue')

    plt.xlabel('Recall', fontsize=fontsize-4)
    plt.ylabel('Precision', fontsize=fontsize-4)
    plt.ylim([0.0, 1.05])
    plt.xlim([0.0, 1.0])
    plt.title('2-class Precision-Recall curve: AP={0:0.2f}'.format(avg_precision), fontsize=fontsize-4)

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()


def split_graph_into_small_clusters(G, remaining_edge_list, percentile_val, indegree_threshold, exclude_edges):
    graph_dict = {"L0": [(G, len(G.nodes))]}  # L0: the original graph

    # split graph into several connected components -- L1
    l1_graph_list = list(nx.connected_component_subgraphs(G))
    l1_graph_list = [(graph, nx.number_of_edges(graph)) for graph in l1_graph_list]
    l1_graph_list = sorted(l1_graph_list, key=lambda x: x[1])
    if len(l1_graph_list) > 1:  # otherwise, no sub graphs
        graph_dict["L1"] = l1_graph_list  # L1 --> split into several subgraph

    # if percentile_val == 85 and indegree_threshold == 100:  # further split the largest cluster for this special case
    #     this_nodes = l1_graph_list[-1][0].nodes
    #     this_graph_edges = []
    #     for (src_id, tgt_id) in remaining_edge_list:
    #         if src_id in this_nodes and tgt_id in this_nodes:
    #             if (src_id, tgt_id) in exclude_edges:
    #                 continue
    #             this_graph_edges.append([src_id, tgt_id])
    #
    #     subG = nx.Graph()  # undirected
    #     subG.add_edges_from(this_graph_edges)
    #
    #     l2_graph_list = list(nx.connected_component_subgraphs(subG))
    #     l2_graph_list = [(graph, nx.number_of_edges(graph)) for graph in l2_graph_list]
    #     l2_graph_list = sorted(l2_graph_list, key=lambda x: x[1])
    #     graph_dict["L2"] = l2_graph_list

    return graph_dict


def get_dev_scores_for_models_on_one_sensor(dev_res_folder):
    df = None
    for fn in os.listdir(dev_res_folder):
        if "summary_for_target_sensor_" not in fn:
            continue
        this_df = pd.read_csv(os.path.join(dev_res_folder, fn))
        target_sensor = fn.replace("summary_for_target_sensor_", "").replace(".csv", "")
        this_df[kw_model] = this_df.apply(assignTargetSensor, axis=1, target_sensor=target_sensor)
        this_df = this_df.set_index(kw_model)
        this_df = this_df.drop("source_sensor", axis=1)
        for kw in [kw_sentence_level_dev_bleu_percentiles, kw_sentence_level_dev_word_accuracy_percentiles]:
            for pctile in CONSIDERED_PERCENTILES:
                this_df[kw + "_" + str(pctile)] = this_df.apply(extractPercentile, axis=1, col=kw, pctile=pctile)

        if df is None:
            df = this_df
        else:
            df = pd.concat([df, this_df])

    return df


def extractPercentile(row, col, pctile):
    for tok in row[col].split(";"):
        p, v = tok.split("-")
        if float(p) == pctile:
            return float(v)


def assignTargetSensor(row, target_sensor):
    return row["source_sensor"] + "#" + target_sensor


def getNumberOfTargetSensors(df_dev_scores):
    target_sensors = set(df_dev_scores.index.map(getTargetSensor).values)
    return len(target_sensors)


def getTargetSensor(index):
    return index.split("#")[1]


def getDate(row):
    # 2017-11-01 00:00:00
    return int(row[COL_TS].split()[0].replace("-", ""))


if __name__ == "__main__":
    main()

