"""
https://www.tensorflow.org/tutorials/seq2seq
@article{luong17,
  author  = {Minh{-}Thang Luong and Eugene Brevdo and Rui Zhao},
  title   = {Neural Machine Translation (seq2seq) Tutorial},
  journal = {https://github.com/tensorflow/nmt},
  year    = {2017},
}
"""
from __future__ import print_function
import os, subprocess
from .constants import *
from . import misc
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu
from nmt.utils import evaluation_utils
import nmt.scripts.bleu as bleu
import time
from datetime import timedelta
import pandas as pd


def testForSensorPairs(model_folder, input_file, output_file, nmt_data_folder, inference_list=None, verbose=True, flog=None):
    if inference_list is None:
        cmd_test = buildTestingCommand(model_folder, input_file, output_file)
    else:
        cmd_test = buildTestingCommandWithInferenceList(model_folder, input_file, output_file, nmt_data_folder, inference_list)

    if verbose:
        misc.log(cmd_test, flog)

    p = subprocess.Popen(cmd_test, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()


def evaluateForSensorPairs(ref_file, trans_file, metric, subword_option=None):
    score = evaluation_utils.evaluate(ref_file, trans_file, metric, subword_option)
    return score


def buildTestingCommandWithInferenceList(model_folder, input_file, output_file, nmt_data_folder, inference_list=None):
    if inference_list is None:
        return buildTestingCommand(model_folder, input_file, output_file)
    
    output_folder = "/".join(output_file.split("/")[:-1])
    output_filename = output_file.split("/")[-1]
    output_folder = os.path.join(output_folder, FOLDER_ATTENTION_IMAGES)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    src, tgt = model_folder.split("/")[-1].split("#")

    cmd = "python -m nmt.nmt "
    cmd += "--out_dir=" + str(model_folder) + " "
    cmd += "--inference_input_file=" + str(input_file) + " "
    cmd += "--inference_output_file=" + str(os.path.join(output_folder, output_filename)) + " "

    # cmd += "--infer_batch_size=1 "  # must specify in the training
    cmd += "--inference_list=" + str(",".join([str(x) for x in inference_list])) + " "

    cmd += "--src=" + str(src) + " --tgt=" + str(tgt) + " "
    cmd += "--vocab_prefix=" + os.path.join(nmt_data_folder, kw_vocab) + "  "

    return cmd


def buildTestingCommand(model_folder, input_file, output_file):
    cmd = "python -m nmt.nmt "
    cmd += "--out_dir=" + str(model_folder) + " "
    cmd += "--inference_input_file=" + str(input_file) + " "
    cmd += "--inference_output_file=" + str(output_file) + " "

    return cmd


def trainForSensorPairs(sensor1, sensor2, data_folder, model_folder, params, verbose=True, flog=None):
    try:
        # set "infer_batch_size=1" --> to show the attention image for every test sampe
        infer_batch_size = params["infer_batch_size"]
    except KeyError:
        infer_batch_size = None

    cmd_train = buildTrainingCommand(sensor1, sensor2, data_folder, model_folder,
                num_train_steps=params["num_train_steps"],
                steps_per_stats=params["steps_per_stats"],
                num_layers=params["num_layers"],
                num_units=params["num_units"],
                dropout=params["dropout"],
                metrics=params["metrics"],
                infer_batch_size=infer_batch_size)
    if verbose:
        misc.log(cmd_train, flog)

    time_prefix = "[time]" + sensor1 + "#" + sensor2
    begin_time = time.time()
    misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog, 2)

    p = subprocess.Popen(cmd_train, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()

    end_time = time.time()
    misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog, 2)
    duration = end_time - begin_time
    misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog, 2)
    misc.log("", flog)
    if flog:
        flog.flush()

    if not os.path.exists(model_folder):
        os.makedirs(model_folder)
    for out in [FN_STDOUT, FN_STDERR]:
        fout = open(os.path.join(model_folder, out), "wb")
        if out == FN_STDOUT:
            fout.write(stdout)
        elif out == FN_STDERR:
            fout.write(stderr)
        fout.close()


def buildTrainingCommand(source, target, data_folder, model_folder, 
                        num_train_steps=10, steps_per_stats=5, num_layers=2, num_units=128,
                        dropout=0.2, metrics=kw_bleu, infer_batch_size=None):
    cmd = "python -m nmt.nmt "
    cmd += "--attention=scaled_luong "
    cmd += "--src=" + str(source) + " --tgt=" + str(target) + " "
    cmd += "--vocab_prefix=" + os.path.join(data_folder, kw_vocab) + "  "
    cmd += "--train_prefix=" + os.path.join(data_folder, kw_train) + "  "
    cmd += "--dev_prefix=" + os.path.join(data_folder, kw_dev) + "  "
    cmd += "--test_prefix=" + os.path.join(data_folder, kw_test) + "  "
    cmd += "--out_dir=" + model_folder + " "
    cmd += "--num_train_steps=" + str(num_train_steps) + " "
    cmd += "--steps_per_stats=" + str(steps_per_stats) + " "
    cmd += "--num_layers=" + str(num_layers) + " "
    cmd += "--num_units=" + str(num_units) + " "
    cmd += "--dropout=" + str(dropout) + " "
    cmd += "--metrics=" + str(metrics) + " "

    if infer_batch_size is not None:
        # This must specify in the training command, 
        # in order to support "inference_list" in infering (to save attention images for them)
        # by default, it is set to be 32
        cmd += "--infer_batch_size=" + str(infer_batch_size) + " "  
    
    return cmd


def generateVisualizationCommand(model_folder, port=22222):
    cmd = "tensorboard --port " + str(port) + " --logdir " + model_folder
    return cmd


def generateVimDiffCommand(kw, source, target, nmt_data_folder, nmt_model_folder):
    cmd = "vimdiff " + os.path.join(nmt_data_folder, kw + "." + target) + " "
    cmd += os.path.join(nmt_model_folder, source + kw_scat + target, "output_" + kw)
    return cmd


# copied from tensorflow nmt tutorial
# Follow //transconsole/localization/machine_translation/metrics/bleu_calc.py
def compute_bleu(ref_file, trans_file, ts_index=None):
    """Compute BLEU scores and handling BPE."""
    max_order = 4
    smooth = False

    # read current day only
    df_ref = pd.read_csv(ref_file, header=None, names=["ref"])
    if ts_index is not None:
        df_ref = df_ref.loc[ts_index]
    # print df_ref.index

    df_trans = pd.read_csv(trans_file, header=None, names=["trans"])
    if ts_index is not None:
        df_trans = df_trans.loc[ts_index]
    # print df_trans.index

    reference_text = []
    reference_text.append(df_ref["ref"].values)

    per_segment_references = []
    for references in zip(*reference_text):
        reference_list = []
        for reference in references:
            reference = reference.strip()
            reference_list.append(reference.split(" "))
        per_segment_references.append(reference_list)

    translations = []
    for idx in df_trans.index:
        line = df_trans.loc[idx]["trans"]
        translations.append(line.split(" "))

    # bleu_score, precisions, bp, ratio, translation_length, reference_length
    bleu_score, _, _, _, _, _ = bleu.compute_bleu(
        per_segment_references, translations, max_order, smooth)
    return 100 * bleu_score


# copied from tensorflow nmt tutorial
def compute_word_accuracy(ref_file, trans_file):
    """Compute accuracy on per word basis."""
    with open(ref_file, "rb") as label_fh:
        with open(trans_file, "rb") as pred_fh:
            total_acc, total_count = 0., 0.
            for sentence in label_fh:
                labels = sentence.strip().split(" ")
                preds = pred_fh.readline().strip().split(" ")
                match = 0.0
                for pos in range(min(len(labels), len(preds))):
                    label = labels[pos]
                    pred = preds[pos]
                    if label == pred:
                        match += 1
                total_acc += 100 * match / max(len(labels), len(preds))
                total_count += 1
    return total_acc / total_count

