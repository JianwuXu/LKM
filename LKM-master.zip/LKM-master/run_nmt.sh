#!/usr/bin/env bash

echo "========== nmt2_train.py =========="
python nmt2_train.py
sleep 30

echo "========== nmt3_more_test.py =========="
python nmt3_more_test.py
sleep 30

echo "========== nmt4_decode_translated_time_series.py =========="
python nmt4_decode_translated_time_series.py
sleep 30


echo "========== nmt7_summarize_score.py =========="
python nmt7_summarize_score.py

sleep 30
echo "========== nmt8_model_precision_and_recall.py =========="
python nmt8_precision_and_recall_per_model.py




