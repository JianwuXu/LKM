tot_num_discrete_time_series = 668  (1 < cardinality <= 5)

after remove time series that are constant on the abnormal day
remaining_num_sensors = 378

