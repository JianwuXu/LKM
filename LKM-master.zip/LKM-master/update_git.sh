#!/usr/bin/env bash
rm *.pyc

if [ "$1" == "" ]; then
   message="update"
else
   message=$1
fi

git add .
git add -u
git commit -m "${message}"
git push origin master

