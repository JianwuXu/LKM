tensorboard --port 22222 --logdir tmp/nmt_attention_model/

