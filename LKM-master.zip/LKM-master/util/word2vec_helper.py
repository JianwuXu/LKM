from __future__ import print_function
import collections
import random
import numpy as np

"""
http://adventuresinmachinelearning.com/word2vec-tutorial-tensorflow/
"""


def collect_data(vocabulary, vocabulary_size):
    data, count, dictionary, reverse_dictionary = build_dataset(vocabulary, vocabulary_size)
    del vocabulary  # Hint to reduce memory.
    return data, count, dictionary, reverse_dictionary


#### prepare dataset for word2vec
#### n_words: extract <n_words> most frequent words
def build_dataset(words, n_words):
    """Process raw inputs into a dataset."""

    # count[0] is 'UNK'. Then, extend with <n_words> most common words (order by descending frequency)
    count = [['UNK', -1]]
    count.extend(collections.Counter(words).most_common(n_words - 1))  # extract <n_words> most frequent words

    # dictionary['unk'] = 0
    # dictionary[<most common word>] = 1
    # dictionary[<second most common word>] = 2
    # ...
    # this step assigns a unique key to each word
    dictionary = dict()
    for word, _ in count:
        dictionary[word] = len(dictionary)

    # data: stores the words by their keys
    data = list()
    unk_count = 0
    for word in words:
        if word in dictionary:
            index = dictionary[word]
        else:
            index = 0  # dictionary['UNK']
            unk_count += 1
        data.append(index)
    count[0][1] = unk_count  # to update 'UNK' count

    reversed_dictionary = dict(zip(dictionary.values(), dictionary.keys()))

    return data, count, dictionary, reversed_dictionary


data_index = 0
# generate batch data (mini-batch for training)
def generate_batch(data, batch_size, num_skips, skip_window):
    global data_index
    assert batch_size % num_skips == 0
    assert num_skips <= 2 * skip_window
    batch = np.ndarray(shape=(batch_size), dtype=np.int32)
    context = np.ndarray(shape=(batch_size, 1), dtype=np.int32)
    span = 2 * skip_window + 1  # [ skip_window input_word skip_window ]
    buffer = collections.deque(maxlen=span)
    for _ in range(span):
        buffer.append(data[data_index])
        data_index = (data_index + 1) % len(data)
    for i in range(batch_size // num_skips):
        target = skip_window  # input word at the center of the buffer
        targets_to_avoid = [skip_window]
        for j in range(num_skips):
            while target in targets_to_avoid:
                target = random.randint(0, span - 1)
            targets_to_avoid.append(target)
            batch[i * num_skips + j] = buffer[skip_window]  # this is the input word
            context[i * num_skips + j, 0] = buffer[target]  # these are the context words
        buffer.append(data[data_index])
        data_index = (data_index + 1) % len(data)

    # Backtrack a little bit to avoid skipping words in the end of a batch
    data_index = (data_index + len(data) - span) % len(data)
    return batch, context

