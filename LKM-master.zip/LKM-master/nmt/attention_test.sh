cat > tmp/my_infer_file.vi
# (copy and paste some sentences from /tmp/nmt_data/tst2013.vi)

python -m nmt.nmt \
    --out_dir=tmp/nmt_attention_model \
    --inference_input_file=tmp/my_infer_file.vi \
    --inference_output_file=tmp/nmt_attention_model/output_infer

cat tmp/nmt_attention_model/output_infer # To view the inference as output
