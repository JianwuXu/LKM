from __future__ import print_function
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from util.constants import *
from collections import OrderedDict, defaultdict, Counter
from util import misc, graph_util, xml_generator
import matplotlib.pyplot as plt


fig_ext = ".pdf"
fontsize = 14
fig_size = (8, 2)
colors = {kw_normal: 'steelblue', kw_abnormal: 'darkred'}

# for each abnormal day, consider <num_padding_normal_days> before and after
num_padding_normal_days = 2

AbnormalDaysToTest = {
        "P1": ["20160619"],  # 20160619 06:22:00 ~ ?
        "P2": ["20110724"],  # 20110724 20:40:00 ~ 20110724 22:55:00
        "P9": ["20161201"],  # 20161201 11:12:00 ~ ?
    }


"""
Combine models run from ALL servers
Plot a directed graph for all models with strong bleu score --> i.e., stronger than top 10 percentile
"""


def main():
    for month in ["P9", "P1", "P2"][:1]:
        fig_folder = os.path.join(FOLDER_FIGS, month + "_numunit64")
        if not os.path.exists(fig_folder):
            os.makedirs(fig_folder)

        nmt_data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
        sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None, comment="#").values.flatten()
        sensor_list = list(sensor_list)

        script_name = os.path.basename(__file__)
        log_filename_prefix = script_name.split("_")[0] + "_" + month
        flog = open(os.path.join(FOLDER_LOGS, log_filename_prefix + ".txt"), "w")
        root_result_folder = os.path.join(FOLDER_NMT_MORE_INFER, "results_" + col_type)
        res_folder_list = os.listdir(root_result_folder)
        res_folder_list.sort()

        df_dev_scores = None
        tot_num_folder = len(res_folder_list)
        for i_folder, month_folder_kw in enumerate(res_folder_list):
            if month not in month_folder_kw:
                continue
            misc.log("[" + str(i_folder+1) + "/" + str(tot_num_folder) + "] Handling folder: " + month_folder_kw, flog)

            dev_res_folder = os.path.join(FOLDER_NMT_MORE_INFER, col_type, month_folder_kw)
            this_df_dev_scores = get_dev_scores_for_models_on_one_sensor(dev_res_folder)

            if df_dev_scores is None:
                df_dev_scores = this_df_dev_scores
            else:
                df_dev_scores = pd.concat([df_dev_scores, this_df_dev_scores])

        num_target_sensors = getNumberOfTargetSensors(df_dev_scores)

        """
        using a fixed threshold value (i.e., 85) or top 10 percentile
        """
        """"""
        #  So far, bleu and word accuracy give the same observation
        metric_list = [kw_avg_daily_dev_bleu, kw_avg_daily_dev_word_accuracy][:1]
        model_dev_score_threshold = {55: 70, 70: 85, 85: 100}
        """"""
        
        for using_metric in metric_list:
            for percentile_val in sorted(model_dev_score_threshold):
                fout = open(os.path.join(fig_folder, "graph_hot_target_sensors_" + using_metric + "_thresh" + str(percentile_val) + "-" + str(model_dev_score_threshold[percentile_val]) + ".txt"), "w")
                misc.log("Using metric: " + using_metric, fout)

                annotate_str = "dev_score_threshold=" + str(round(percentile_val, 1)) + "~" + str(round(model_dev_score_threshold[percentile_val], 1))
                fig_name = os.path.join(fig_folder, "histogram_of_model_dev_score_" + using_metric + fig_ext)
                if not os.path.exists(fig_name):
                    plot_histogram_of_model_dev_scores(using_metric, df_dev_scores[using_metric], percentile_val, annotate_str, fig_name)
                misc.log("***" + annotate_str, flog)

                if model_dev_score_threshold[percentile_val] == 100:
                    _df = df_dev_scores[(df_dev_scores[using_metric] >= percentile_val) & (df_dev_scores[using_metric] <= model_dev_score_threshold[percentile_val])]
                else:
                    _df = df_dev_scores[(df_dev_scores[using_metric] >= percentile_val) & (df_dev_scores[using_metric] < model_dev_score_threshold[percentile_val])]
                misc.log(using_metric + " " + annotate_str + " num_strong_models=" + str(_df.shape[0]), flog)
                plot_strong_models_as_directed_graph(using_metric, [percentile_val, model_dev_score_threshold[percentile_val]], _df, sensor_list, num_target_sensors, annotate_str, df_dev_scores.shape[0], fig_folder, fout)

                fp_xml = os.path.join(fig_folder, month + "." + using_metric + ".thresh" + str(percentile_val) + "-" + str(model_dev_score_threshold[percentile_val]) + ".inv.xml")
                xml_generator.buildInvariantsXML(month, _df[[using_metric]], using_metric, percentile_val, fp_xml)

                fout.close()
        flog.close()


def plot_strong_models_as_directed_graph(using_metric, percentile_val, this_df_dev_score, sensor_list, num_target_sensors, annotate_str, tot_model, fig_folder, fout,
                                         indegree_threshold=100, strict_indegree_threshold=125):
    #####
    ## indegree_threshold: threshold to determine a popular target sensor
    #####

    # #### assign reference number to sensor names
    # id_to_sensor = pd.DataFrame(columns=["id", "sensor_name"])
    # for model in this_df_dev_score.index.values:
    #     src, tgt = model.split("#")
    #     for sensor in [src, tgt]:
    #         sensor_id = sensor_list.index(sensor)
    #         # id_to_sensor[sensor_id] = sensor
    #         id_to_sensor.loc[sensor_id] = {"id": sensor_id, "sensor_name": sensor}
    #
    # id_to_sensor.sort_index(inplace=True)
    # id_to_sensor.to_csv(os.path.join(fig_folder, "graph_sensor_name_references.csv"), index=False)

    misc.log("\n***" + annotate_str + "***", fout)
    misc.log("*** " + str(this_df_dev_score.shape[0]) + " out of " + str(tot_model) + " are strong models.", fout)

    # #### plot graph for all sensors
    edge_list = []
    tgt_to_src, src_to_tgt = defaultdict(int), defaultdict(int)
    for model in this_df_dev_score.index.values:
        src, tgt = model.split("#")
        src_id = sensor_list.index(src)
        tgt_id = sensor_list.index(tgt)
        edge_list.append((src_id, tgt_id))
        tgt_to_src[tgt_id] += 1
        src_to_tgt[src_id] += 1

    fp_degree = os.path.join(fig_folder, "graph_sensor_indegree_" + using_metric + "_thresh" + str(percentile_val[0]) + "-" + str(percentile_val[1]) + ".csv")
    df_degree = pd.DataFrame(columns=[kw_sensor_id, kw_sensors, kw_in_degree, kw_out_degree])
    for sid, sensor in enumerate(sensor_list):
        d_in = tgt_to_src[sid] if sid in tgt_to_src else 0
        d_out = src_to_tgt[sid] if sid in src_to_tgt else 0
        df_degree.loc[sid] = {kw_sensor_id: sid, kw_sensors: sensor, kw_in_degree: d_in, kw_out_degree: d_out}
    df_degree = df_degree.sort_values(kw_in_degree, ascending=False)
    df_degree.to_csv(fp_degree, index=False)

    #### exclude popular target sensors (with in-degree >= <indegree_threshold>)
    remaining_edge_list = []
    hot_target_sensors = {strict_indegree_threshold: dict(), indegree_threshold: dict()}
    for (src_id, tgt_id) in edge_list:
        if tgt_to_src[tgt_id] >= strict_indegree_threshold:
            newline = "Sensor-" + str(tgt_id) + ": " + sensor_list[tgt_id] + " in-degree=" + str(tgt_to_src[tgt_id])
            hot_target_sensors[strict_indegree_threshold][tgt_id] = newline
        elif tgt_to_src[tgt_id] >= indegree_threshold:
            newline = "Sensor-" + str(tgt_id) + ": " + sensor_list[tgt_id] + " in-degree=" + str(tgt_to_src[tgt_id])
            hot_target_sensors[indegree_threshold][tgt_id] = newline
        else:
            remaining_edge_list.append((src_id, tgt_id))

    misc.log("num_target_sensors=" + str(num_target_sensors), fout)
    misc.log("num_target_sensors_with_strong_relation=" + str(len(tgt_to_src)), fout)
    misc.log("HOT target sensors:", fout)
    tot_num_hot_target_sensors = 0
    for threshold in [strict_indegree_threshold, indegree_threshold]:
        tot_num_hot_target_sensors += len(hot_target_sensors[threshold])
        for tgt_id in sorted(hot_target_sensors[threshold]):
            misc.log(hot_target_sensors[threshold][tgt_id], fout, 2)

    num_remaining = len(remaining_edge_list)
    misc.log("After exclude HOT target sensors, num_remaining_edges=" + str(num_remaining), fout)

    fig_name = os.path.join(fig_folder, "graph_" + using_metric + "_thresh" + str(percentile_val[0]) + "-" + str(percentile_val[1]) + fig_ext)
    this_annotate_str = annotate_str
    this_annotate_str += "\n# target sensors = " + str(num_target_sensors)
    this_annotate_str += "\nnum_edges=" + str(this_df_dev_score.shape[0])
    this_annotate_str += "\nnum_hot_target_sensors=" + str(tot_num_hot_target_sensors)
    graph_util.plot_graph_given_edge_list(edge_list, fig_name,
                     show_label=True, hot_nodes=hot_target_sensors,
                     edge_alpha=0.2,
                     annotate_str=this_annotate_str)

    fig_name = os.path.join(fig_folder, "graph_" + using_metric + "_thresh" + str(percentile_val[0]) + "-" + str(percentile_val[1]) + "_partial" + fig_ext)
    this_annotate_str = annotate_str
    this_annotate_str += "\n# target sensors = " + str(num_target_sensors)
    this_annotate_str += "\nnum_edges=" + str(num_remaining)
    graph_util.plot_graph_given_edge_list(remaining_edge_list, fig_name, show_label=True,
                     edge_alpha=0.2, node_size_normal=50,
                     annotate_str=this_annotate_str)


def get_dev_scores_for_models_on_one_sensor(dev_res_folder):
    df = None
    for fn in os.listdir(dev_res_folder):
        if "summary_for_target_sensor_" not in fn:
            continue
        this_df = pd.read_csv(os.path.join(dev_res_folder, fn))
        target_sensor = fn.replace("summary_for_target_sensor_", "").replace(".csv", "")
        this_df[kw_model] = this_df.apply(assignTargetSensor, axis=1, target_sensor=target_sensor)
        this_df = this_df.set_index(kw_model)
        this_df = this_df.drop("source_sensor", axis=1)
        if df is None:
            df = this_df
        else:
            df = pd.concat([df, this_df])

    return df


def assignTargetSensor(row, target_sensor):
    return row["source_sensor"] + "#" + target_sensor


def get_source_and_target_sensors(res_folder):
    target_to_source = dict()
    target_sensors = []
    for fn in os.listdir(res_folder):
        model = fn.replace(".csv", "")
        src, tgt = misc.getSourceAndTargetFromModelName(model)
        if not src:  # invalid model name
            continue
        if tgt not in target_to_source:
            target_to_source[tgt] = []
            target_sensors.append(tgt)
        target_to_source[tgt].append(src)
    return target_sensors, target_to_source


def plot_histogram_of_model_dev_scores(kw, df, percentile_val, annotate_str, fig_name, fontsize=14):
    fig, ax = plt.subplots(figsize=(3.75, 2.5))
    df.plot.hist(ax=ax, bins=20, normed=True)

    ax.axvline(x=percentile_val, linestyle="dotted", color="red")

    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    ax.annotate(annotate_str, (x_min+1, y_max-0.002), verticalalignment="top", fontsize=fontsize-4)

    ax.set_xlabel(kw, fontsize=fontsize-4)

    ax.set_axisbelow(True)
    ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
    ax.tick_params('both', which="both", direction='in')

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()


def getNumberOfTargetSensors(df_dev_scores):
    target_sensors = set(df_dev_scores.index.map(getTargetSensor).values)
    return len(target_sensors)


def getTargetSensor(index):
    return index.split("#")[1]


if __name__ == "__main__":
    main()

