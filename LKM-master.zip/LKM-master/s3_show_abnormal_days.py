from __future__ import print_function

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as dates
from matplotlib import gridspec

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from collections import OrderedDict, defaultdict
from util.constants import *


fig_ext = ".pdf"
# fig_ext = ".png"
colors = {kw_normal: "steelblue", kw_abnormal: "darkred"}


def main():
    fourth_order_data_folder = "data_v4"  # encrypt to letters

    # df_sensor_description = getSensorDescription(filename="data/sensor_description.csv")
    df_sensor_description = None  # most sensors' name cannot be found in "sensor_description.csv"

    # extract from doc/issue_list.xlsx -- provided by FALCON
    # abnormal_days = getAbnormalDays(filename=os.path.join("data/issue_list.csv"), D2D=["success", "fail"])
    abnormal_days = {
        "P1": ["20160619"],
        "P2": ["20110724"],
        "P9": ["20161201"],
    }

    for month in ["P9", "P1", "P2"][2:]:
        # sensor_list = get201711Sensors(fourth_order_data_folder, month)

        sensor_list = pd.read_csv(os.path.join(fourth_order_data_folder, col_type, month, kw_sensors), header=None, comment="#").values.flatten()
        # print(sensor_list)

        fig_folder = os.path.join(fourth_order_data_folder, FOLDER_FIGS + "_" + col_type, month)
        if not os.path.exists(fig_folder):
            os.makedirs(fig_folder)
        # randomPickSensors = False if month in ["201711", "201708", "201802"] else True
        randomPickSensors = False

        step = 20
        for start in range(0, len(sensor_list), step):
            specified_sensors = sensor_list[start: start + step]
            plotAbnormalDays(month, abnormal_days[month], fourth_order_data_folder, fig_folder,
                             randomPickSensors=randomPickSensors, num_picks=1, specified_sensors=specified_sensors,
                             df_sensor_description=df_sensor_description)

"""
#### Plot abnormal days -- including one day before and one day after to show the context
"""
def plotAbnormalDays(month, abnormal_days, fourth_order_data_folder, fig_folder,
                     randomPickSensors=True, num_picks=5, specified_sensors=None,
                     df_sensor_description=None,
                     fontsize=14):
    print("***", month, "Abnormal days:", abnormal_days)

    fp_data = os.path.join(fourth_order_data_folder, col_type, month + ".csv")
    if not os.path.exists(fp_data):
        return
    df = pd.read_csv(fp_data, nrows=None)

    sensors = list(df.columns.values)
    sensors.remove(COL_TS)
    selected_sensors = sensors
    if randomPickSensors:
        # #### random pick up ONE sensor per cardinality
        selected_sensors = randomPickupSensorByCardinality(df, sensors, num_picks=num_picks)
        print("selected sensors:", selected_sensors)
    if specified_sensors is not None:
        selected_sensors = specified_sensors

    remaining_sensors = []
    for sid, sensor_name in enumerate(sensors):
        if sensor_name not in selected_sensors:
            continue
        fig_name = os.path.join(fig_folder, "sensor" + str(sid) + "+" + sensor_name + fig_ext)
        if os.path.exists(fig_name):
            continue
        remaining_sensors.append(sensor_name)

    df[kw_day] = df.apply(getDate, axis=1)
    df.set_index(COL_TS, inplace=True)
    # df[selected_sensors] = df[selected_sensors].applymap(converCharToInt)
    df[remaining_sensors] = df[remaining_sensors].applymap(converCharToInt)

    tot_days = len(abnormal_days)
    for sid, sensor_name in enumerate(sensors):
        if sensor_name not in remaining_sensors:
            continue
        # if sensor_name not in selected_sensors:
        #     continue
        #
        fig_name = os.path.join(fig_folder, "sensor" + str(sid) + "+" + sensor_name + fig_ext)
        # if os.path.exists(fig_name):
        #     continue

        sensor_description = ""
        if df_sensor_description is not None:
            _sn = "_".join(sensor_name.split("_")[1:])
            try:
                this_sensor = df_sensor_description.loc[_sn]
                if this_sensor.shape[0] > 1:
                    this_sensor = this_sensor.iloc[0]
                sensor_description = this_sensor["Description"] + " (System=" + this_sensor["System"] + ")"
            except KeyError:
                pass

        print("***[" + str(sid) + "]", sensor_name)
        this_df = df[[kw_day, sensor_name]]
        fig = plt.figure(figsize=(20, 1.2 * tot_days))
        gs = gridspec.GridSpec(tot_days, 1, left=0.05, hspace=0.5)
        for i, abnormal_day in enumerate(abnormal_days):
            print("\t", abnormal_day)

            one_day_before = str(datetime.strptime(abnormal_day, "%Y%m%d").date() - timedelta(days=1)).replace("-", "")
            one_day_after = str(datetime.strptime(abnormal_day, "%Y%m%d").date() + timedelta(days=1)).replace("-", "")

            df_before = this_df[this_df[kw_day] == one_day_before]
            df_abnormal = this_df[this_df[kw_day] == abnormal_day]
            df_after = this_df[this_df[kw_day] == one_day_after]
            # print df_before.shape, df_abnormal.shape, df_after.shape

            # dfs = {kw_normal: {one_day_before: df_before, one_day_after: df_after},
            #         kw_abnormal: {abnormal_day: df_abnormal}}
            dfs = {kw_abnormal: {abnormal_day: df_abnormal}, kw_normal: {}}
            if df_before.shape[0] > 0:
                dfs[kw_normal][one_day_before] = df_before
            if df_after.shape[0] > 0:
                dfs[kw_normal][one_day_after] = df_after

            ax = plt.subplot(gs[i])
            cur_days = []
            for kw in [kw_normal, kw_abnormal]:
                for cur_d in dfs[kw]:
                    cur_days.append(cur_d)
                    time_base = datetime.strptime(cur_d, "%Y%m%d")
                    time_list = [time_base + timedelta(minutes=x) for x in range(dfs[kw][cur_d].shape[0])]
                    x = time_list
                    y = dfs[kw][cur_d][sensor_name]
                    ax.step(x, y, linestyle="solid", color=colors[kw])

            if i == 0:
                title = "Sensor-" + str(sid) + ": " + str(sensor_name)
                if sensor_description != "":
                    title += "\n" + sensor_description
                ax.set_title(title, fontsize=fontsize)

            if i == tot_days-1:
                ax.set_xlabel("Hour", fontsize=fontsize-4)

            if one_day_before in dfs[kw_normal]:
                x_min = dfs[kw_normal][one_day_before].index.values[0]
            else:
                x_min = dfs[kw_abnormal][abnormal_day].index.values[0]
            if one_day_after in dfs[kw_normal]:
                x_max = dfs[kw_normal][one_day_after].index.values[-1]
            else:
                x_max = dfs[kw_abnormal][abnormal_day].index.values[-1]
            ax.set_xlim(x_min, x_max)

            ymin, ymax = ax.get_ylim()
            # txt_y = (ymin + ymax) / 2.0
            # ax.text(datetime.strptime(x_max, "%Y-%m-%d %H:%M:%S")+timedelta(minutes=3), txt_y, abnormal_day, fontsize=fontsize-6, va='center')
            for cur_d in cur_days:
                ax.axvline(x=cur_d, color='0.8', linestyle="dotted")
                ax.text(cur_d, ymax, cur_d, fontsize=fontsize-4, va='bottom')

            ax.xaxis.set_major_locator(dates.HourLocator(interval=2))
            ax.xaxis.set_major_formatter(dates.DateFormatter('%H'))  # %Y%m%d
            ax.tick_params('both', which="both", direction='in')

        plt.savefig(fig_name, bbox_inches='tight')
        # plt.tight_layout()
        # plt.show()
        plt.close()


def randomPickupSensorByCardinality(df, sensors, num_picks=1):
    # pick up one sensor per cardinality
    # selected_sensors = OrderedDict()
    selected_sensors = []
    df_uni = pd.DataFrame(df[sensors].nunique(), columns=["cardinality"])
    for c, _df in df_uni.groupby("cardinality"):
        this_pick = min(num_picks, _df.shape[0])
        row = _df.sample(n=this_pick, random_state=RANDOM_SEED)
        for i in range(this_pick):
            # selected_sensors[row.index.values[i]] = c
            selected_sensors.append(row.index.values[i])
    return selected_sensors


def converCharToInt(cell):
    return ord(cell) - ord('a') + 1


def getDate(row):
    # 2017-11-01 00:00:00
    return row[COL_TS].split()[0].replace("-", "")


def getAbnormalDays(filename, D2D=["success", "fail", "-"]):
    df = pd.read_csv(filename)
    df = df[df["D2D"].isin(D2D)]
    abnormal = dict()
    for month, dfm in df.groupby("month"):
        this_days = list(dfm["abnormal_day"].unique())
        this_days.sort()
        abnormal[str(month)] = [str(d) for d in this_days]
    return abnormal


def getSensorDescription(filename):
    df = pd.read_csv(filename)
    df.set_index("TAG", inplace=True)
    return df


def get201711Sensors(fourth_order_data_folder, month):
    fdata = os.path.join(fourth_order_data_folder, col_type, month + "_" + kw_ref + ".csv")
    df = pd.read_csv(fdata, usecols=["sensor"])
    return df["sensor"].values


if __name__ == "__main__":
    main()