from .falcon_constants import *
import os

host_lkm_laptop = "SSCLG7520L9N"
host_lkm_server = "nndev4"

# host running falcon
KNOWN_HOSTS = [host_lkm_laptop, host_lkm_server]

if not os.path.exists(FOLDER_LOGS):
    os.makedirs(FOLDER_LOGS)