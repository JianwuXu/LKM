MONTH_LIST = ["201708", "201709", "201710", "201711", "201712", "201801", "201802"]
GRANULARITY = 1  # contain record every minute --> so 1440=60*24 records per day

FOLDER_CAT = "categorical"
FOLDER_MIX = "mixed"
col_type = FOLDER_CAT  # current focus on categorical time series only!

FOLDER_RAW_DATA = "raw_data"  # contains original, unprocessed FALCON data

kw_ts = "timestamp"
kw_day = "day"
kw_ref = "reference"

RANDOM_SEED = 123

kw_scat = "#"  # used to concat two sensor ids

# commonly used column names
COL_TS = "timestamp"

# folder names
FOLDER_PARAMS = "parameters"
FOLDER_WORDS = "words"
FOLDER_SENTENCES = "sentences"
FOLDER_EMBEDDINGS = "embeddings"
FOLDER_DATA = "data"
FOLDER_FIGS = "figs"
FOLDER_LOGS = "logs"
FOLDER_RESULTS = "results"
FOLDER_SUMMARY = "summary"
# intermediate folders begin with "_"
FOLDER_NMT_DATA = "_nmt_data"
FOLDER_NMT_MODEL = "_nmt_model"
FOLDER_NMT_INFER = "_nmt_infer"

### folders for more test cases
FOLDER_NMT_MORE_DATA = "_nmt_more_data"
FOLDER_NMT_MORE_INFER = "_nmt_more_infer"

FOLDER_ATTENTION_IMAGES = "attention_images"

folder_model_daily_scores = "model_daily_scores"
folder_model_scores_normal_vs_abnormal = "model_scores_normal_vs_abnormal"
folder_model_sentence_level_scores = "model_sentence_level_scores"

FN_STDOUT = "stdout.log"
FN_STDERR = "stderr.log"

# keywords
kw_sensor_id = "sensor_id"
kw_sensors = "sensors"
kw_train = "train"
kw_dev = "dev"
kw_test = "test"
kw_full_test = "full_test"
kw_infer = "infer"
kw_vocab = "vocab"

kw_bleu = "bleu"
kw_bleu_smooth = "bleu_smooth"
kw_accuracy = "accuracy"
kw_word_accuracy = "word_accuracy"
kw_edit_distance = "edit_dist"  # calculating edit distance is time consuming, as compared to bleu/word accuracy

EVALUATION_METRIC_CANDIDATES = [kw_bleu, kw_word_accuracy, kw_edit_distance][:2]
EVALUATION_METRIC_CANDIDATES_PER_SENTENCE = [kw_bleu, kw_word_accuracy, kw_edit_distance]

CONSIDERED_PERCENTILES = [0.1, 0.25, 0.5, 0.75, 0.9]

kw_model = "model"
kw_src_sensor = "source_sensor"
kw_tgt_sensor = "target_sensor"
kw_day = "day"
kw_case = "case"

kw_input = "input"
kw_ground_truth = "ground_truth"
kw_translation = "translation"
kw_prediction = "prediction"   # this is the anomaly_score for anomaly detection
kw_broken_cnt = "brokenCount"

abbrevations = {kw_input: "Input", kw_ground_truth: "GT", kw_translation: "Tran."}

kw_last_step = "last_step"
kw_best_step = "best_step"
kw_best_step_dev_bleu = "best_step_dev_bleu"
kw_best_step_test_bleu = "best_step_test_bleu"
kw_last_step_dev_bleu = "last_step_dev_bleu"
kw_last_step_test_bleu = "last_step_test_bleu"
kw_avg_daily_dev_bleu = "avg_daily_dev_bleu"
kw_avg_daily_dev_word_accuracy = "avg_daily_dev_word_accuracy"

kw_avg_sentence_level_dev_bleu = "avg_sentence_level_dev_bleu"
kw_avg_sentence_level_dev_word_accuracy = "avg_sentence_level_dev_word_accuracy"

kw_sentence_level_dev_bleu_percentiles = "sentence_level_dev_bleu_percentiles"
kw_sentence_level_dev_word_accuracy_percentiles = "sentence_level_dev_word_accuracy_percentiles"

kw_tp = "tp"
kw_precision = "precision"
kw_recall = "recall"
kw_predicted_abnormal_days = "predicted_abnormal_days"

kw_graph_id = "graph_id"
kw_in_degree = "in_degree"
kw_out_degree = "out_degree"


kw_sentence = "sentence"
kw_timeseries = "timeseries"

kw_normal, kw_abnormal = "normal", "abnormal"
kw_gt = "GT"

split_by_ratio = "ratio"
split_by_dates = "dates"

vi_pca, vi_tsne = "pca", "t-sne"

host_macair, host_am1605, host_srgpu02 = "macair", "am1605", "srgpu02"

# shae.nec-labs.com
host_shae = "shae"

# valyrian.nec-labs.com
host_valyrian = "valyrian"

# sr18-pc01
host_sr18pc01 = "sr18pc01"

# sr17-01
host_sr1701 = "sr1701"

host_snow = "snow"

# [longclaw]: it contains two virtual machines
# (1) 138.15.170.118
host_event1 = "event1"
# (2) 138.15.170.139
host_ngla3 = "ngla3"

# [ygritte]: it contains two virtual machines
# (1) 138.15.170.137
# host_nglabmles = "nglabmles" -- discard
# (2) 138.15.170.140
host_nglaGitlabRunner = "nglaGitlabRunner"
# (3) 138.15.170.134
host_event2 = "event2"

# [tyrion]: it contains three virtual machines
# (1) 138.15.170.112
host_ngla1 = "ngla1"
# (2) 138.15.170.146
# host_ngla6 = "ngla6"  -- discarded
# (3) 138.15.170.105
# host_SIAT1 = "SIAT1"  -- discarded
# (4) 138.15.170.144
host_jianwu1 = "jianwu1"


# host running falcon
KNOWN_HOSTS = [host_am1605, host_srgpu02,
               host_shae, host_valyrian, host_sr18pc01,
               host_event1, host_ngla3,
               host_nglaGitlabRunner,
               host_sr1701]

BASELINE_HOSTS = [host_ngla1, host_jianwu1, host_event2]


threshold_dev_bleu = 85
threshold_dev_word_accuracy = 85