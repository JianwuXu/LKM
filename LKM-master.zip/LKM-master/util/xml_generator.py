def buildInvariantsXML(month, _df, using_metric, percentile_val, fp_xml):
    fout = open(fp_xml, "w")
    fout.write('<Invariants model="' + month + '.' + using_metric + '.nmt">\n')
    builtInfo(fout, using_metric, percentile_val, _df.shape[0])
    for idx in _df.index:
        src, tgt = idx.split("#")
        score = _df.loc[idx][using_metric]
        builtInvariant(fout, src, tgt, score)
    fout.write("</Invariants>\n")
    fout.close()


def builtInvariant(fout, src, tgt, score):
    fout.write("\t<Invariant>\n")
    fout.write("\t\t<uName>" + str(src) + "</uName>\n")
    fout.write("\t\t<yName>" + str(tgt) + "</yName>\n")
    fout.write("\t\t<fitness>" + str(round(score/100., 6)) + "</fitness>\n")
    fout.write("\t</Invariant>\n")


def builtInfo(fout, using_metric, percentile_val, invCount):
    fout.write("\t<Info>\n")
    fout.write("\t\t<" + str(using_metric) + ">" + str(percentile_val/100.) + "</" + str(using_metric) + ">\n")
    fout.write("\t\t<invCount>" + str(invCount) + "</invCount>\n")
    fout.write("\t</Info>\n")

