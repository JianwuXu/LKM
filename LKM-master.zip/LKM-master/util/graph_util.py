import matplotlib.pyplot as plt
import networkx as nx


def plot_graph_given_graph(G, fig_name=None, show_label=False, hot_nodes=None, title=None, annotate_str=None, fontsize=14,
               edge_alpha=0.7, node_size_normal=20, node_size_hot=260, figsize=(10, 8)):

    plt.figure(figsize=figsize)

    # Need to create a layout when doing
    # separate calls to draw nodes and edges
    pos = nx.spring_layout(G)

    if hot_nodes is not None:  # assign special care to those HOT nodes
        max_indegree = max([G.in_degree(v) for v in G])
        node_size = [G.in_degree(v) * (node_size_hot / max_indegree) for v in G]
        node_size = [node_size_normal if v < node_size_normal else v for v in node_size]

        thresholds = sorted(hot_nodes.keys())
        colors = {"normal": "steelblue",  thresholds[-1]: "lightcoral"}
        node_color = []
        for v in G:
            if v in hot_nodes[thresholds[-1]]:
                node_color.append(colors[thresholds[-1]])
            else:
                node_color.append(colors["normal"])

        node_label = dict()
        for p in pos:
            # node_label[p] = p if p in hot_nodes else ""
            found = False
            for thresh in thresholds:
                if p in hot_nodes[thresh]:
                    node_label[p] = p
                    found = True
            if not found:
                node_label[p] = ""

        nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                               node_color=node_color, node_size=node_size)
        if show_label:
            nx.draw_networkx_labels(G, pos, labels=node_label, font_size=fontsize-6)

    else:
        nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                               node_color='steelblue', node_size=node_size_normal)
        if show_label:
            nx.draw_networkx_labels(G, pos, font_size=fontsize-6)

    nx.draw_networkx_edges(G, pos, arrows=True, edge_color='0.4', alpha=edge_alpha)

    ax = plt.gca()
    if title:
        ax.set_title(title, fontsize=fontsize-4)

    if annotate_str:
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        ax.annotate(annotate_str, (x_min + 0.02, y_min + 0.02), fontsize=fontsize-4)

    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.tick_params('both', which="both", direction='in')

    if fig_name:
        plt.savefig(fig_name, bbox_inches='tight')
    else:
        plt.tight_layout()
        plt.show()
    plt.close()


def plot_graph_given_color_edge_list(edge_list, fig_name=None, color_edges=[],  pos=None, show_label=False, hot_nodes=None, title=None,
                                     annotate_str=None, annotate_str_fontsize=10, fontsize=14,
               edge_alpha=0.7, node_size_normal=20, node_size_hot=260, figsize=(10, 8), k=0.35, scale=1):

    plt.figure(figsize=figsize)

    G = nx.DiGraph()
    # G.add_edges_from(
    #     [('A', 'B'), ('A', 'C'), ('D', 'B'), ('E', 'C'), ('E', 'F'),
    #      ('B', 'H'), ('B', 'G'), ('B', 'F'), ('C', 'G')])
    G.add_edges_from(edge_list)

    # Need to create a layout when doing
    # separate calls to draw nodes and edges
    if pos is None:
        pos = nx.spring_layout(G, k=k, scale=scale)
    else:
        nx.spring_layout(G, pos=pos, k=k, scale=scale)

    if hot_nodes is not None:  # assign special care to those HOT nodes
        max_indegree = max([G.in_degree(v) for v in G])
        node_size = [G.in_degree(v) * (node_size_hot / max_indegree) for v in G]
        node_size = [node_size_normal if v < node_size_normal else v for v in node_size]

        thresholds = sorted(hot_nodes.keys())
        colors = {"normal": "steelblue",  thresholds[-1]: "lightcoral"}
        node_color = []
        for v in G:
            if v in hot_nodes[thresholds[-1]]:
                node_color.append(colors[thresholds[-1]])
            else:
                node_color.append(colors["normal"])

        node_label = dict()
        for p in pos:
            # node_label[p] = p if p in hot_nodes else ""
            found = False
            for thresh in thresholds:
                if p in hot_nodes[thresh]:
                    node_label[p] = p
                    found = True
            if not found:
                node_label[p] = ""

        nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                               node_color=node_color, node_size=node_size)
        if show_label:
            nx.draw_networkx_labels(G, pos, labels=node_label, font_size=fontsize-6)

    else:
        nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                               node_color='steelblue', node_size=node_size_normal)
        if show_label:
            nx.draw_networkx_labels(G, pos, font_size=fontsize-6)

    nx.draw_networkx_edges(G, pos, arrows=True, edge_color='0.4', alpha=edge_alpha)
    nx.draw_networkx_edges(G, pos, edgelist=color_edges, edge_color='darkred', arrows=True, alpha=edge_alpha)

    ax = plt.gca()
    if title:
        ax.set_title(title, fontsize=fontsize-4)

    if annotate_str:
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        ax.annotate(annotate_str, (x_min + 0.02, y_min + 0.02), fontsize=annotate_str_fontsize)

    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.tick_params('both', which="both", direction='in')

    if fig_name:
        plt.savefig(fig_name, bbox_inches='tight')
    else:
        plt.tight_layout()
        plt.show()
    plt.close()


def plot_graph_given_edge_list(edge_list, fig_name=None, show_label=False, hot_nodes=None, title=None, annotate_str=None, fontsize=14,
               edge_alpha=0.7, node_size_normal=20, node_size_hot=260, figsize=(10, 8), k=0.35, scale=1):

    plt.figure(figsize=figsize)

    G = nx.DiGraph()
    # G.add_edges_from(
    #     [('A', 'B'), ('A', 'C'), ('D', 'B'), ('E', 'C'), ('E', 'F'),
    #      ('B', 'H'), ('B', 'G'), ('B', 'F'), ('C', 'G')])
    G.add_edges_from(edge_list)

    # Need to create a layout when doing
    # separate calls to draw nodes and edges
    pos = nx.spring_layout(G, k=k, scale=scale)

    if hot_nodes is not None:  # assign special care to those HOT nodes
        max_indegree = max([G.in_degree(v) for v in G])
        node_size = [G.in_degree(v) * (node_size_hot / max_indegree) for v in G]
        node_size = [node_size_normal if v < node_size_normal else v for v in node_size]

        thresholds = sorted(hot_nodes.keys())
        colors = {"normal": "steelblue",  thresholds[-1]: "lightcoral"}
        node_color = []
        for v in G:
            if v in hot_nodes[thresholds[-1]]:
                node_color.append(colors[thresholds[-1]])
            else:
                node_color.append(colors["normal"])

        node_label = dict()
        for p in pos:
            # node_label[p] = p if p in hot_nodes else ""
            found = False
            for thresh in thresholds:
                if p in hot_nodes[thresh]:
                    node_label[p] = p
                    found = True
            if not found:
                node_label[p] = ""

        nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                               node_color=node_color, node_size=node_size)
        if show_label:
            nx.draw_networkx_labels(G, pos, labels=node_label, font_size=fontsize-6)

    else:
        nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                               node_color='steelblue', node_size=node_size_normal)
        if show_label:
            nx.draw_networkx_labels(G, pos, font_size=fontsize-6)

    nx.draw_networkx_edges(G, pos, arrows=True, edge_color='0.4', alpha=edge_alpha)

    ax = plt.gca()
    if title:
        ax.set_title(title, fontsize=fontsize-4)

    if annotate_str:
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        ax.annotate(annotate_str, (x_min + 0.02, y_min + 0.02), fontsize=fontsize-4)

    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.tick_params('both', which="both", direction='in')

    if fig_name:
        plt.savefig(fig_name, bbox_inches='tight')
    else:
        plt.tight_layout()
        plt.show()
    plt.close()

    return pos


def plot_graph_example(edge_list):
    G = nx.DiGraph()
    G.add_edges_from(
        [('A', 'B'), ('A', 'C'), ('D', 'B'), ('E', 'C'), ('E', 'F'),
         ('B', 'H'), ('B', 'G'), ('B', 'F'), ('C', 'G')])

    val_map = {'A': 1.0,
               'D': 0.5714285714285714,
               'H': 0.0}

    values = [val_map.get(node, 0.25) for node in G.nodes()]

    # Specify the edges you want here
    red_edges = [('A', 'C'), ('E', 'C')]
    edge_colours = ['black' if not edge in red_edges else 'red'
                    for edge in G.edges()]
    black_edges = [edge for edge in G.edges() if edge not in red_edges]

    # Need to create a layout when doing
    # separate calls to draw nodes and edges
    pos = nx.spring_layout(G)
    nx.draw_networkx_nodes(G, pos, cmap=plt.get_cmap('jet'),
                           node_color=values, node_size=500)
    nx.draw_networkx_labels(G, pos)
    nx.draw_networkx_edges(G, pos, edgelist=red_edges, edge_color='r', arrows=True)
    nx.draw_networkx_edges(G, pos, edgelist=black_edges, arrows=False)
    plt.show()


# if __name__ == "__main__":
#     plot_graph_example(None)