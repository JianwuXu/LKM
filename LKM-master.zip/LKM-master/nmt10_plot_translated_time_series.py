from __future__ import print_function
import os, socket
hostname = socket.gethostname()
if "nec-labs.com" in hostname:
    nrows = None
else:
    nrows = None
    import matplotlib
    matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as dates

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
from util import preprocessing, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import heapq
from collections import defaultdict, Counter, OrderedDict
from datetime import datetime, timedelta
from nltk.metrics import edit_distance
import helper_nmt
import time
import random

from PyPDF2 import PdfFileMerger
import xml.etree.ElementTree as ET

# random.seed(RANDOM_SEED)
random.seed(1)

"""
Visualize test day-by-day
"""
#### Translate X --> Y, show three time series:
#### (1) input: X (_nmt_more_data/test.X)
#### (2) ground_truth: Y (_nmt_more_data/test.Y)
#### (3) translation: Y (_nmt_more_infer/infer.Y.normal)
display_length = 60 * 24  # one day

"""
### on average: 22 seconds per model score calculation
### on average: 10 seconds per model time series plot
"""

AbnormalDaysToTest = {
        "P1": ["20160619"],  # 20160619 06:22:00 ~ ?
        "P2": ["20110724"],  # 20110724 20:40:00 ~ 20110724 22:55:00
        "P9": ["20161201"],  # 20161201 11:12:00 ~ ?
    }


def main():
    for month in ["P9", "P1", "P2"][:1]:
        script_name = os.path.basename(__file__)
        flog = open(os.path.join(FOLDER_LOGS, script_name.split("_")[0] + "_" + month + ".txt"), "w")

        time_prefix = "[overall-time]"
        begin_time = time.time()
        misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog)

        prepareForTargetMonth(month, display_length, flog)

        end_time = time.time()
        misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog)
        duration = end_time - begin_time
        misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog)
        flog.close()


def prepareForTargetMonth(month, truncate, flog):
    #### load parameters
    param_filename = "params_" + col_type + "_" + month + ".json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    filename = month + ".csv"
    data_filename = os.path.join(params["data_folder"], col_type, filename)
    print(data_filename)
    
    base_data_folder = FOLDER_NMT_MORE_DATA
    base_infer_folder = FOLDER_NMT_MORE_INFER

    nmt_data_folder = os.path.join(base_data_folder, col_type, month)
    fig_folder = os.path.join(base_infer_folder, FOLDER_FIGS + "_" + col_type, month)
    nmt_infer_folder = os.path.join(base_infer_folder, col_type)
    res_folder = os.path.join(base_infer_folder, FOLDER_RESULTS + "_" + col_type)

    # model --> trained server (folder name)
    trained_model_to_folder_name = helper_nmt.get_model_server_assignment(month, res_folder, folder_model_sentence_level_scores)
    sensor_list = pd.read_csv(os.path.join(FOLDER_NMT_DATA, col_type, month, kw_sensors), header=None).values.flatten()
    sensor_list = list(sensor_list)

    """"""
    # target_model_sensor_ids = [(32, 36)]

    # target_model_sensor_ids = getTargetModels(sensor_list=sensor_list,
    #                                           fp_data=os.path.join(FOLDER_FIGS, month + "_numunit64", month + ".avg_daily_dev_bleu.inv.xml"))
    # target_model_sensor_ids.append((32, 36))
    # target_model_sensor_ids.append((54, 56))
    # target_model_sensor_ids.append((58, 56))

    if month == "201711":
        target_model_sensor_ids = [(32, 36), (126, 67), (68, 53), (50, 55)]
    elif month == "201712":
        target_model_sensor_ids = [(69, 68), (19, 17)]
    """"""

    target_models = []
    for (src_id, tgt_id) in target_model_sensor_ids:
        src = sensor_list[src_id]
        tgt = sensor_list[tgt_id]
        target_models.append(src + "#" + tgt)

    tot_target_models = len(target_models)
    for i_model, target_model in enumerate(target_models):
        misc.log("[" + str(i_model + 1) + "/" + str(tot_target_models) + "]Target model: " + target_model, flog)

        if target_model not in trained_model_to_folder_name:
            continue
        plotTranslatedTimeSeriesOnDailyBasis(month, fig_folder, res_folder, target_model, trained_model_to_folder_name[target_model],
                                               nmt_infer_folder, nmt_data_folder, params["data_preparation"], sensor_list,
                                               flog=flog)


def getTargetModels(sensor_list, fp_data, in_degree_threshold=100, num_picks=1):
    tgt_to_src = defaultdict(list)
    tree = ET.parse(fp_data)
    root = tree.getroot()
    for invariant in root:
        if invariant.tag != "Invariant":
            continue
        src, tgt, score = "", "", 0
        for child in invariant:
            if child.tag == "uName":
                src = child.text
            elif child.tag == "yName":
                tgt = child.text
            elif child.tag == "fitness":
                score = float(child.text) * 100
        tgt_to_src[tgt].append(src)

    target_model_sensor_ids = []
    sensor_list = list(sensor_list)
    for tgt in tgt_to_src:
        tgt_id = sensor_list.index(tgt)
        this_list = tgt_to_src[tgt]
        if len(this_list) > in_degree_threshold:  # exclude those popular targets
            continue
        random.shuffle(this_list)
        for src in this_list[:num_picks]:
            src_id = sensor_list.index(src)
            target_model_sensor_ids.append((src_id, tgt_id))

    return target_model_sensor_ids


def plotTranslatedTimeSeriesOnDailyBasis(month, fig_folder, res_folder, target_model, target_model_folder_name, nmt_infer_folder, nmt_data_folder,
                               params, sensor_list, flog=None):
    if not os.path.exists(fig_folder):
        os.makedirs(fig_folder)

    source_sensor, target_sensor = target_model.split("#")
    src_id, tgt_id = sensor_list.index(source_sensor), sensor_list.index(target_sensor)
    daily_score_folder = os.path.join(res_folder, target_model_folder_name, folder_model_daily_scores)

    #### collect timestamp info -- timestamp of every test sentence
    fp_ts = os.path.join(nmt_data_folder, kw_test + "." + COL_TS)
    df_ts = pd.read_csv(fp_ts, header=None, names=[COL_TS])
    df_ts[kw_day] = df_ts.apply(getDate, axis=1)
    # print(df_ts.shape)

    #### get (2) ground_truth time series
    fp_groundtruth = os.path.join(nmt_data_folder, kw_test + "." + target_sensor)
    df_groundtruth, timeseries_groundtruth = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnDailyBasis(
        fp_groundtruth, df_ts, params, display_length)

    day_list = list(timeseries_groundtruth.keys())
    day_list.sort()
    # for day in day_list:
    #     print(day, len(timeseries_groundtruth[day]))

    ######
    # plot time series each model
    ######
    #### check if done with all days for current model
    # all_done = True
    # for day in day_list:
    #     fig_name = os.path.join(fig_folder, target_model + "#" + day + "#infer.pdf").replace("#", "+")
    #     if not os.path.exists(fig_name):
    #         all_done = False
    #         break
    # if all_done:
    #     misc.log("Already plotted all days for model: " + target_model + ". Skip", flog)
    #     return

    fig_name_one = os.path.join(fig_folder, str(src_id) + "-" + str(tgt_id) + "#" + target_model + "#infer.pdf").replace("#", "+")
    if os.path.exists(fig_name_one):
        misc.log("Already plotted all days for model: " + target_model + ". Skip", flog)
        return

    this_infer_folder = os.path.join(nmt_infer_folder, target_model_folder_name, target_model)
    if not misc.checkExistence(this_infer_folder):
        misc.log("!!!Cannot find " + this_infer_folder + ".Skip.", flog, 3)
        return

    fp_model_res = os.path.join(daily_score_folder, target_model + ".csv")
    if os.path.exists(fp_model_res):
        df_model_res = pd.read_csv(fp_model_res)
        df_model_res.set_index(kw_day, inplace=True)
    else:
        # misc.log("!!!Cannot find file " + fp_model_res + ". Skip.", flog, 3)
        # return
        df_model_res = None


    #### get (1) get input time series
    fp_input = os.path.join(nmt_data_folder, kw_test + "." + source_sensor)
    df_input, timeseries_input = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnDailyBasis(
        fp_input, df_ts, params, display_length)

    #### get (3) translated time series
    fp_translation = os.path.join(this_infer_folder, kw_infer + "." + source_sensor + "." + kw_normal)
    df_translation, timeseries_translation = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnDailyBasis(
        fp_translation, df_ts, params, display_length)

    #### prepare timeseries df  -- on a daily basis
    fig_list = []
    for day in day_list:
        print(day)

        fig_name = os.path.join(fig_folder, "_tmp_" + str(src_id) + "-" + str(tgt_id) + "#" + target_model + "#" + day + "#infer.pdf").replace("#", "+")
        fig_list.append(fig_name)
        if os.path.exists(fig_name):
            print("\tPlotted. Skip.")
            continue

        df = pd.DataFrame(columns=[kw_input, kw_ground_truth, kw_translation])
        ts_input = timeseries_input[day]
        ts_ground_truth = timeseries_groundtruth[day]
        ts_translation = timeseries_translation[day]
        min_len = min(len(ts_input), len(ts_ground_truth), len(ts_translation))

        df[kw_input] = list(ts_input[:min_len])
        df[kw_ground_truth] = list(ts_ground_truth[:min_len])
        df[kw_translation] = list(ts_translation[:min_len])

        df = df.applymap(converCharToInt)
        # print(df)

        this_daily_scores = df_model_res.loc[int(day)] if df_model_res is not None else None
        plot_discrete_time_seres(month, fig_name, day, df, target_model, this_daily_scores, str(src_id) + "-" + str(tgt_id))

    #### end plotting for one model


    ### merge figures of different days to one pdf!
    merger = PdfFileMerger()
    for pdf in fig_list:
        merger.append(pdf)
    merger.write(fig_name_one)

    ### clean up
    for pdf in fig_list:
        if os.path.exists(pdf):
            os.remove(pdf)


def plot_discrete_time_seres(month, fig_name, day, df, target_model, daily_scores, model_id, fontsize=14):
    # fig_name = os.path.join(fig_folder, target_model + "#" + day + "#infer.pdf").replace("#", "+")

    size = df.shape[1]
    f, ax_arr = plt.subplots(size, 1, sharex=True, sharey=False, figsize=(7, size))
    for i, col in enumerate([kw_input, kw_ground_truth, kw_translation]):
        ax = ax_arr[i]
        if i == 0:
            title = "Model:" + target_model.replace("#", "-->")
            title += " (" + model_id + ")"
            title += "\n" + kw_day + "=" + str(day)
            if daily_scores is not None:
                title += "\n" + kw_avg_daily_dev_bleu + "=" + str(round(daily_scores[kw_avg_daily_dev_bleu], 2))
                title += ", " + kw_avg_daily_dev_word_accuracy + "=" + str(round(daily_scores[kw_avg_daily_dev_word_accuracy], 2))
            ax.set_title(title, fontsize=fontsize-6)

        # x = range(df.shape[0])
        time_base = datetime.strptime(day, "%Y%m%d")
        time_list = [time_base + timedelta(minutes=x) for x in range(df.shape[0])]
        x = time_list
        y = df[col].values

        color = "darkred" if day in AbnormalDaysToTest[month] else "steelblue"
        ax.step(x, y, linestyle="solid", color=color)

        if col == kw_translation and daily_scores is not None:
            ymin, ymax = ax.get_ylim()
            txt_y = (ymin + ymax) / 2.0

            txt = ""
            for score in [kw_bleu, kw_word_accuracy, kw_edit_distance][:-1]:
                txt += score + "=\n" + str(round(daily_scores[score], 2)) + "\n"
            if daily_scores[kw_bleu] < daily_scores[kw_avg_daily_dev_bleu]:
                text_color = "red"
            else:
                text_color = "k"
            ax.text(x[-1]+timedelta(minutes=3), txt_y, txt[:-1], fontsize=fontsize-6, va='center', color=text_color)

        ax.set_ylabel(abbrevations[col], fontsize=fontsize-4)
        if i == size-1:
            ax.set_xlabel("Hour", fontsize=fontsize-4)

        # ax.set_xlim(-1, len(x))
        ax.xaxis.set_major_locator(dates.HourLocator(interval=1))
        ax.xaxis.set_major_formatter(dates.DateFormatter('%H'))
        ax.set_xlim(x[0], x[-1])

        ax.set_axisbelow(True)
        ax.yaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
        ax.xaxis.grid(b=True, which='major', color='0.8', linestyle='dotted')
        ax.tick_params('both', which="both", direction='in')

        for tick in ax.xaxis.get_major_ticks():
            tick.label.set_fontsize(fontsize - 6)
        for tick in ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(fontsize - 6)

    plt.savefig(fig_name, bbox_inches='tight')
    # plt.show()
    plt.close()


def converCharToInt(cell):
    return ord(cell) - ord('a') + 1


def getDate(row):
    return row[COL_TS].split()[0].replace("-", "")


if __name__ == "__main__":
    main()
