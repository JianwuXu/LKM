from __future__ import print_function
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from util.constants import *
from collections import OrderedDict, defaultdict, Counter
from util import misc, graph_util
import matplotlib.pyplot as plt
import matplotlib.dates as dates
import networkx as nx
import helper_nmt
import sklearn.metrics as skm

fig_ext = ".pdf"
fontsize = 14
fig_size = (8, 2)
colors = {kw_normal: 'steelblue', kw_abnormal: 'darkred'}

# for each abnormal day, consider <num_padding_normal_days> before and after
num_padding_normal_days = 2

AbnormalDaysToTest = {
        "P1": [20160619],  # 20160619 06:22:00 ~ ?
        "P2": [20110724],  # 20110724 20:40:00 ~ 20110724 22:55:00
        "P9": [20161201],  # 20161201 11:12:00 ~ ?
    }

DevDays = {"P1": [], "P2": [], "P9": []}

"""
Combine models run from ALL servers
Plot a directed graph for all models with strong bleu score --> i.e., stronger than top 10 percentile
"""

# VOTE_THRESHOLD = 0.6  # i.e., if >80% models/edges in the cluster vote for this day, then this day is abnormal

MONTH_WITH_TRAINED_MODELS = "201711"


def main():
    for month in ["P9", "P1", "P2"][:1]:
        """
        For LKM, train and infer with difference cases separately
        """
        global MONTH_WITH_TRAINED_MODELS
        MONTH_WITH_TRAINED_MODELS = month

        nmt_data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
        root_result_folder = os.path.join(FOLDER_NMT_MORE_INFER, "results_" + col_type)
        trained_model_to_folder_name = helper_nmt.get_model_server_assignment(month, root_result_folder, folder_model_sentence_level_scores)
        sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None, comment="#").values.flatten()
        sensor_list = list(sensor_list)

        script_name = os.path.basename(__file__)
        log_filename_prefix = script_name.split("_")[0] + "_" + month
        flog = open(os.path.join(FOLDER_LOGS, log_filename_prefix + ".txt"), "w")

        df_dev_scores = None
        res_folder_list = os.listdir(root_result_folder)
        res_folder_list.sort()
        tot_num_folder = len(res_folder_list)
        for i_folder, month_folder_kw in enumerate(res_folder_list):
            if month not in month_folder_kw:
                continue
            misc.log("[" + str(i_folder + 1) + "/" + str(tot_num_folder) + "] Handling folder: " + month_folder_kw,
                     flog)

            dev_res_folder = os.path.join(FOLDER_NMT_MORE_INFER, col_type, month_folder_kw)
            dev_res_folder = dev_res_folder.replace(month, MONTH_WITH_TRAINED_MODELS)
            this_df_dev_scores = get_dev_scores_for_models_on_one_sensor(dev_res_folder)

            if df_dev_scores is None:
                df_dev_scores = this_df_dev_scores
            else:
                df_dev_scores = pd.concat([df_dev_scores, this_df_dev_scores])

        # num_target_sensors = getNumberOfTargetSensors(df_dev_scores)

        """
        # set anomaly detection parameters here
        """
        # (1) evaluation metric: kw_avg_sentence_level_dev_bleu or kw_avg_sentence_level_dev_word_accuracy
        metric_list = [kw_avg_sentence_level_dev_bleu]

        # (2) model_dev_score_threshold: strong: [85:100], medium: [70:85), weak: [55:70)
        # (3) graph_level:
        #       (3-1) "before_removing_hot_sensors" -- contain all connections
        #       (3-2) "L0_0": remove popular sensors from graph "before_removing_hot_sensors"
        model_dev_score_threshold = {70: 85}  # so far, medium connection works better
        graph_level = ["before_removing_hot_sensors"]   # for medium connections, it is better to use "before_removing_hot_sensors"

        # model_dev_score_threshold = {85: 100}  # so far, medium connection works better
        # graph_level = ["L0_0"]  # for strong connections, it is better to use "L0_0"

        # (4) indegree_threshold: if a sensor with in-degree >= indegree_threshold, it is considered as a popular sensor in (3-2)
        indegree_threshold = [100, 125][:1]

        # (5) cutoff: if anomaly_score >= cutoff --> detect an anomaly
        cutoff = [0.9]
        """
        # END set anomaly detection parameters here
        """

        infer_metric = {}
        for kw in metric_list:
            if kw_bleu in kw:
                infer_metric[kw] = kw_bleu
            elif kw_word_accuracy in kw:
                infer_metric[kw] = kw_word_accuracy

        for using_metric in metric_list:
            for percentile_val in sorted(model_dev_score_threshold)[::-1]:
                for indegree_thresh in indegree_threshold:
                    misc.log("using_metric:" + using_metric, flog)
                    misc.log("dev_score_threshold=" + str(percentile_val) + "~" + str(model_dev_score_threshold[percentile_val]), flog)
                    misc.log("indegree_thresh=" + str(indegree_thresh), flog)
                    if model_dev_score_threshold[percentile_val] == 100:
                        _df = df_dev_scores[(df_dev_scores[using_metric] >= percentile_val) & (df_dev_scores[using_metric] <= model_dev_score_threshold[percentile_val])]
                    else:
                        _df = df_dev_scores[(df_dev_scores[using_metric] >= percentile_val) & (df_dev_scores[using_metric] < model_dev_score_threshold[percentile_val])]

                    if month == "201711" and percentile_val == 85 and indegree_threshold == 100:
                        exclude_edges = [(68, 53), (50, 55)]
                    else:
                        exclude_edges = []

                    fig_folder = os.path.join(FOLDER_FIGS, month + "_numunit64_at_sentence_level",
                                          "connected_subgraphs_" + using_metric + "_thresh" + str(percentile_val) + "-" + str(model_dev_score_threshold[percentile_val]) + "_indegree_thresh_" + str(indegree_thresh))
                    if not os.path.exists(fig_folder):
                        os.makedirs(fig_folder)
                    for this_cutoff in cutoff:
                        misc.log("cutoff: anomaly_score>=" + str(this_cutoff), flog)
                        generate_SIAT_format_anomaly_files(month, using_metric, graph_level, this_cutoff, _df, sensor_list, percentile_val, indegree_thresh, trained_model_to_folder_name,
                                                 fig_folder, root_result_folder, infer_metric, exclude_edges=exclude_edges, flog=flog)
        flog.close()


def generate_SIAT_format_anomaly_files(month, using_metric, graph_level, cutoff, df, sensor_list, percentile_val, indegree_threshold, trained_model_to_folder_name,
                             fig_folder, root_result_folder, infer_metric, exclude_edges=[], flog=None):
    edge_list = []
    tgt_to_src = defaultdict(int)
    for model in df.index:
        src, tgt = model.split("#")
        src_id = sensor_list.index(src)
        tgt_id = sensor_list.index(tgt)
        edge_list.append((src_id, tgt_id))
        tgt_to_src[tgt_id] += 1

    if "before_removing_hot_sensors" in graph_level and indegree_threshold == 100:
        ori_G = nx.Graph()
        ori_G.add_edges_from(edge_list)
        graph_id = "before_removing_hot_sensors"
        generate_anomaly_xml_file(month, graph_id, ori_G, edge_list, df, sensor_list, using_metric, infer_metric, cutoff,
                              trained_model_to_folder_name, root_result_folder, fig_folder, )

    remaining_edge_list = []  # exclude those hot target sensor -- those connected to almost every one!
    for (src_id, tgt_id) in edge_list:
        if tgt_to_src[tgt_id] >= indegree_threshold:
            continue
        remaining_edge_list.append((src_id, tgt_id))

    # G = nx.DiGraph()  # directed  -- does not support nx.connected_component_subgraphs(G)
    G = nx.Graph()  # undirected
    G.add_edges_from(remaining_edge_list)

    graph_dict = split_graph_into_small_clusters(G, remaining_edge_list, percentile_val, indegree_threshold, exclude_edges)
    graph_list = []
    for level in sorted(graph_dict):
        for i, (graph, num_edges) in enumerate(graph_dict[level]):
            graph_list.append((level + "_" + str(i), graph))

    for graph_id, graph in graph_list:
        if graph_id not in graph_level:
            continue

        # anomaly detection
        # generate anomaly.xml and anomaly.txt in SIAT
        generate_anomaly_xml_file(month, graph_id, graph, remaining_edge_list, df, sensor_list, using_metric, infer_metric, cutoff,
                          trained_model_to_folder_name, root_result_folder, fig_folder, flog)


def generate_anomaly_xml_file(month, graph_id, graph, remaining_edge_list, df, sensor_list, using_metric, infer_metric, cutoff,
                          trained_model_to_folder_name, root_result_folder, fig_folder, flog=None):
    #### fp_anomaly_txt is a summary of fp_anomaly_xml, while fp_anomaly_xml contain detailed broken invariant info
    fp_anomaly_xml = os.path.join(fig_folder, "graph_" + graph_id + "_anomaly_cutoff_" + str(cutoff) + ".xml")
    fp_anomaly_txt = fp_anomaly_xml.replace(".xml", ".txt")

    # if os.path.exists(fp_anomaly_xml) and os.path.exists(fp_anomaly_txt):
    #     print("Find " + fp_anomaly_xml + " and " + fp_anomaly_txt + ". Skip.")
    #     return

    fp_pred = os.path.join(fig_folder, "graph_" + str(graph_id) + ".csv")
    if not os.path.exists(fp_pred):
        print("Cannot find " + fp_pred)
        return
    print(fp_pred)

    # in df_pred: kw_prediction is anomaly score for anomaly detection task
    df_pred = pd.read_csv(fp_pred)

    # as = anomaly score
    # mean_as, var_as, std_as, max_brk_cnt_at, max_as_at
    mean_as = df_pred[kw_prediction].mean()
    var_as = df_pred[kw_prediction].var()
    std_as = df_pred[kw_prediction].std()

    max_as_at = []
    for idx in df_pred[df_pred[kw_prediction] == df_pred[kw_prediction].max()].index:
        _max_as_at = str(df_pred.loc[idx, kw_prediction]) + " @ " + str(idx)
        max_as_at.append(_max_as_at)

    max_brk_cnt_at = []
    for idx in df_pred[df_pred[kw_broken_cnt] == df_pred[kw_broken_cnt].max()].index:
        _max_brk_cnt_at = str(df_pred.loc[idx, kw_broken_cnt]) + " @ " + str(idx)
        max_brk_cnt_at.append(_max_brk_cnt_at)

    # select timebin whose anomaly_score (kw_prediction) >= cutoff
    df_detected_anomaly = df_pred[df_pred[kw_prediction] >= cutoff]
    anomaly_timebins = df_detected_anomaly[COL_TS].values

    this_nodes = graph.nodes
    fout = open(os.path.join(fig_folder, "graph_" + str(graph_id) + "_sensors.txt"), "w")
    for sensor_id in sorted(this_nodes):
        fout.write("sensor-" + str(sensor_id) + ": " + sensor_list[sensor_id] + "\n")
    fout.close()

    num_valid_models = 0  # total number of models
    timebin_votes = defaultdict(int)  # save the number of votes for each sentence (20min-timebin) voted by every model/edge in the graph
    timebin_voted_models = dict()

    for (src_id, tgt_id) in remaining_edge_list:
        if src_id in this_nodes and tgt_id in this_nodes:
            this_model = sensor_list[src_id] + "#" + sensor_list[tgt_id]
            dev_score = df.loc[this_model, using_metric]

            # such model has dev_score, but no infer score (reason: infer sentence length of different size or with empty lines, skipped)
            if this_model not in trained_model_to_folder_name:
                # print("Cannot find infer scores for " + this_model)
                continue

            num_valid_models += 1
            fp_score = os.path.join(root_result_folder, trained_model_to_folder_name[this_model], "model_sentence_level_scores", this_model + ".csv")

            df_score = pd.read_csv(fp_score)
            df_score[kw_day] = df_score.apply(getDate, axis=1)
            df_score = df_score[~df_score[kw_day].isin(DevDays[month])]
            df_abnormal = df_score[df_score[infer_metric[using_metric]] < dev_score]
            if df_abnormal.shape[0] == 0:  # no abnormal days detected by this model
                continue
            for idx in df_abnormal.index:
                this_df = df_abnormal.loc[idx]
                this_time = this_df[COL_TS]
                timebin_votes[this_time] += 1

                # prepare information used to generate SIAT anomaly.xml
                if this_time in anomaly_timebins:
                    if this_time not in timebin_voted_models:
                        timebin_voted_models[this_time] = dict()
                    this_infer_score = this_df[infer_metric[using_metric]]
                    timebin_voted_models[this_time][str(src_id) + "#" + str(tgt_id)] = [this_infer_score, dev_score]

    ## generate SIAT anomaly.xml
    ## at each timestamp report anomaly_score (kw_prediction) and num_broken_invariant_cnt
    ## only use high-level graph for anomaly detection
    fout = open(fp_anomaly_xml, "w")
    xml_writter("<RCResults>", fout, 0)
    sensors_with_broken_invariants = set()
    tot_fitness = 0
    for idx in df_pred.index:
        this_df = df_pred.loc[idx]
        this_time = this_df[COL_TS]
        is_anomaly = True if this_time in anomaly_timebins else False

        this_anomaly_score = this_df[kw_prediction]
        this_broken_cnt = this_df[kw_broken_cnt] if is_anomaly else 0

        xml_writter("<RCResult>", fout, 1)
        # xml_writter("<period>" + str(this_time) + "</period>", fout, 2)
        xml_writter("<period>" + str(idx) + "</period>", fout, 2)  # idx of timestamp, not timestamp
        xml_writter("<anomalyScore>" + str(this_anomaly_score) + "</anomalyScore>", fout, 2)
        xml_writter("<brokenCount>" + str(this_broken_cnt) + "</brokenCount>", fout, 2)

        if is_anomaly:
            # more info needed for anomaly
            for this_model in sorted(timebin_voted_models[this_time]):
                src_id, tgt_id = this_model.split("#")
                this_infer_score, this_dev_score = timebin_voted_models[this_time][this_model]
                xml_writter("<brokenInvariant>", fout, 2)
                xml_writter("<uName>" + sensor_list[int(src_id)] + "</uName>", fout, 3)
                xml_writter("<yName>" + sensor_list[int(tgt_id)] + "</yName>", fout, 3)
                xml_writter("<residual>" + str(this_infer_score - this_dev_score) + "</residual>", fout, 3)  # infer_score - dev_score
                xml_writter("<fitness>" + str(this_dev_score) + "</fitness>", fout, 3)  # dev_score
                xml_writter("</brokenInvariant>", fout, 2)

                sensors_with_broken_invariants.add(src_id)
                sensors_with_broken_invariants.add(tgt_id)
                tot_fitness += this_dev_score

        xml_writter("</RCResult>", fout, 1)

    xml_writter("</RCResults>", fout, 0)
    fout.close()

    ## generate SIAT anomaly.txt
    fout = open(fp_anomaly_txt, "w")
    misc.log("# of Nodes in the Invariants model:" + str(len(sensors_with_broken_invariants)), fout)
    misc.log("Total Fitness in the Invariants model:" + str(tot_fitness), fout)

    for idx in df_pred.index:
        this_df = df_pred.loc[idx]
        # Time Period=3; Time Point=2014/05/07 00:04:00; Brk Invs=0; Anomaly Score=0.0
        newline = "Time Period=" + str(idx) + "; "
        newline += "Time Point=" + str(this_df[COL_TS]).replace("-", "/") + "; "
        newline += "Brk Invs=" + str(this_df[kw_broken_cnt]) + "; "
        newline += "Anomaly Score=" + str(this_df[kw_prediction])
        misc.log(newline + "\n", fout)

    misc.log("Anomaly Score Average = " + str(mean_as), fout)
    misc.log("Anomaly Score Variance = " + str(var_as), fout)
    misc.log("Anomaly Score Standard Deviation = " + str(std_as) + "\n", fout)
    for _str in max_brk_cnt_at:
        misc.log("Max # of Broken Invariants = " + _str, fout)
    for _str in max_as_at:
        misc.log("Max Anomaly Score = " + _str, fout)
    misc.log("Execution time is 0 seconds", fout)

    fout.close()


def xml_writter(newline, file, num_tabs=0):
    prefix = "".join(["\t"] * num_tabs)
    file.write(prefix + newline + "\n")


def split_graph_into_small_clusters(G, remaining_edge_list, percentile_val, indegree_threshold, exclude_edges):
    graph_dict = {"L0": [(G, len(G.nodes))]}  # L0: the original graph

    # split graph into several connected components -- L1
    l1_graph_list = list(nx.connected_component_subgraphs(G))
    l1_graph_list = [(graph, nx.number_of_edges(graph)) for graph in l1_graph_list]
    l1_graph_list = sorted(l1_graph_list, key=lambda x: x[1])
    if len(l1_graph_list) > 1:  # otherwise, no sub graphs
        graph_dict["L1"] = l1_graph_list  # L1 --> split into several subgraph

    # if percentile_val == 85 and indegree_threshold == 100:  # further split the largest cluster for this special case
    #     this_nodes = l1_graph_list[-1][0].nodes
    #     this_graph_edges = []
    #     for (src_id, tgt_id) in remaining_edge_list:
    #         if src_id in this_nodes and tgt_id in this_nodes:
    #             if (src_id, tgt_id) in exclude_edges:
    #                 continue
    #             this_graph_edges.append([src_id, tgt_id])
    #
    #     subG = nx.Graph()  # undirected
    #     subG.add_edges_from(this_graph_edges)
    #
    #     l2_graph_list = list(nx.connected_component_subgraphs(subG))
    #     l2_graph_list = [(graph, nx.number_of_edges(graph)) for graph in l2_graph_list]
    #     l2_graph_list = sorted(l2_graph_list, key=lambda x: x[1])
    #     graph_dict["L2"] = l2_graph_list

    return graph_dict


def get_dev_scores_for_models_on_one_sensor(dev_res_folder):
    df = None
    for fn in os.listdir(dev_res_folder):
        if "summary_for_target_sensor_" not in fn:
            continue
        this_df = pd.read_csv(os.path.join(dev_res_folder, fn))
        target_sensor = fn.replace("summary_for_target_sensor_", "").replace(".csv", "")
        this_df[kw_model] = this_df.apply(assignTargetSensor, axis=1, target_sensor=target_sensor)
        this_df = this_df.set_index(kw_model)
        this_df = this_df.drop("source_sensor", axis=1)
        for kw in [kw_sentence_level_dev_bleu_percentiles, kw_sentence_level_dev_word_accuracy_percentiles]:
            for pctile in CONSIDERED_PERCENTILES:
                this_df[kw + "_" + str(pctile)] = this_df.apply(extractPercentile, axis=1, col=kw, pctile=pctile)

        if df is None:
            df = this_df
        else:
            df = pd.concat([df, this_df])

    return df


def extractPercentile(row, col, pctile):
    for tok in row[col].split(";"):
        p, v = tok.split("-")
        if float(p) == pctile:
            return float(v)


def assignTargetSensor(row, target_sensor):
    return row["source_sensor"] + "#" + target_sensor


def getNumberOfTargetSensors(df_dev_scores):
    target_sensors = set(df_dev_scores.index.map(getTargetSensor).values)
    return len(target_sensors)


def getTargetSensor(index):
    return index.split("#")[1]


def getDate(row):
    # 2017-11-01 00:00:00
    return int(row[COL_TS].split()[0].replace("-", ""))


if __name__ == "__main__":
    main()

