import os
from util.constants import *
from collections import defaultdict
from datetime import timedelta
import pandas as pd


def main():
    month = "P1"
    check_for_current_month(month)
    check_for_nmt2_training_progress(month)


def check_for_nmt2_training_progress(month):
    model_folder = os.path.join(FOLDER_NMT_MODEL, col_type)
    host_to_files = defaultdict(list)
    for host_folder in os.listdir(model_folder):
        if not os.path.isdir(os.path.join(model_folder, host_folder)):
            continue
        if month not in host_folder:
            continue
        hostname = host_folder.split("_")[1]
        for fn in os.listdir(os.path.join(model_folder, host_folder)):
            if os.path.isdir(os.path.join(model_folder, month + "_" + hostname, fn)):
                continue
            if "SAVE_" in fn:
                continue
            host_to_files[hostname].append(fn)

    for hostname in KNOWN_HOSTS:
        if hostname not in host_to_files:
            continue
        file_list = sorted(host_to_files[hostname])

        if len(file_list) == 0:
            continue
        print("***" + hostname)

        for fn in file_list:

            fdata = open(os.path.join(model_folder, month + "_" + hostname, fn))
            for line in fdata:
                if "Target sensor: " in line:
                    target_sensor = " ".join(line.strip().split()[:-1])
                elif "***[" in line:
                    cur_and_tot = line.strip().split("]")[0].split("[")[1]
            fdata.close()
            print("\t" + target_sensor + ": [" + str(cur_and_tot) + "]")


def check_for_current_month(month):
    host_to_files = defaultdict(list)
    for fn in os.listdir(FOLDER_LOGS):
        hostname = fn.split("_")[0]
        host_to_files[hostname].append(fn)

    for hostname in KNOWN_HOSTS:
        if hostname not in host_to_files:
            continue
        file_list = sorted(host_to_files[hostname])

        all_done = True
        for i, fn in enumerate(file_list):
            is_valid_log = False
            fdata = open(os.path.join(FOLDER_LOGS, fn))
            for line in fdata:
                if "[overall-time] duration=" in line:
                    is_valid_log = True
            fdata.close()
            if not is_valid_log:
                all_done = False
                print("!!!!" + hostname + " Find unfinished log: " + fn)
                break

        if all_done:
            model_folder = os.path.join(FOLDER_NMT_MODEL, col_type, month + "_" + hostname)
            avg_time = get_average_execution_time(model_folder)
            avg_time_str = str(timedelta(seconds=int(avg_time)))

            if i == len(file_list)-1:
                fdata = open(os.path.join(FOLDER_LOGS, fn))
                for line in fdata:
                    if "[overall-time] end=" in line:
                        end_time = " ".join(line.strip().split("=")[-1].split()[:2])
                fdata.close()

            newline = hostname + ":"
            # newline += "\tAvg Model Training Time: " + avg_time_str
            newline += "\tend_time: " + str(end_time)
            print(newline)


def get_average_execution_time(model_folder):
    n = 0
    prev_mean = 0
    for fn in os.listdir(model_folder):
        if os.path.isdir(os.path.join(model_folder, fn)):
            continue
        fdata = open(os.path.join(model_folder, fn))
        for line in fdata:
            if "[time]" in line and "duration=" in line:
                duration = float(line.strip().split("(")[-1].split()[0])  # seconds
                mean = (prev_mean * n + duration) * 1.0 / (n + 1)
                n += 1
                prev_mean = mean
        fdata.close()
    # print(n, mean)
    return mean


if __name__ == "__main__":
    main()


