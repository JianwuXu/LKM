from __future__ import print_function
import os
import pandas as pd
import numpy as np
from datetime import datetime
from util.constants import *
from util.plots import *
from collections import OrderedDict, defaultdict, Counter
import matplotlib.pyplot as plt


fig_ext = ".pdf"


def main():
    # plot_monthly_number_of_sensors()

    # plot_sensor_vocab_size()

    plot_runtime()


def plot_runtime(save_kw="log_"):

    model_folder = os.path.join(FOLDER_NMT_MODEL, col_type)
    for folder_name in os.listdir(os.path.join(model_folder)):
        duration_list = []
        for filename in os.listdir(os.path.join(model_folder, folder_name)):
            if filename[:len(save_kw)] != save_kw:
                continue
            fdata = open(os.path.join(model_folder, folder_name, filename))

            for line in fdata:
                if "duration=" not in line:
                    continue
                # [time]vm-pida_CSO11:MBA10EU010ZV01#vm-pida_BA:ACTIVE.1 duration=0:02:00.063646(120.06364631652832 seconds)
                duration = float(line.strip().split("(")[-1].split()[0])  # in seconds
                duration_list.append(duration)
            fdata.close()

            print("plot runtime for " + filename)
            fig_folder = os.path.join(FOLDER_FIGS, "runtime")
            if not os.path.exists(fig_folder):
                os.makedirs(fig_folder)
            fig_name = os.path.join(fig_folder, folder_name + fig_ext)
            plot_cdf(duration_list, fig_name, xlabel="runtime (second)", ylabel="CDF", title=folder_name, xlogscale=False)


def plot_sensor_vocab_size():
    for month in MONTH_LIST:
        data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)
        if not os.path.exists(data_folder):
            continue
        vocab_size_list = []
        for fn in os.listdir(data_folder):
            if kw_vocab + "." not in fn:
                continue
            df = pd.read_csv(os.path.join(data_folder, fn), header=None)
            vocab_size_list.append(df.shape[0])

        if len(vocab_size_list) < 100:  # these are tries, not the entire month
            continue

        print("plot vocab size for month=" + month)
        fig_folder = os.path.join(FOLDER_FIGS, "vocab_size")
        if not os.path.exists(fig_folder):
            os.makedirs(fig_folder)
        fig_name = os.path.join(fig_folder, month + fig_ext)
        plot_cdf(vocab_size_list, fig_name, xlabel="vocab size", ylabel="CDF", title=month, xlogscale=True)


def plot_monthly_number_of_sensors():
    df = pd.read_csv("data_v3/num_common_sensors_per_month.csv", header=None)
    df["month"] = df.apply(getMonth, axis=1)
    df["num_sensors"] = df.apply(getNumber, axis=1)

    fig, ax = plt.subplots(figsize=(6, 2))
    df.plot.bar(x=df["month"], y=["num_sensors"], ax=ax, legend=False)
    for p in ax.patches:
        ax.annotate(str(int(p.get_height())), (p.get_x() * 1.005, p.get_height() * 1.005))

    ax.tick_params('both', which="both", direction='in')
    ax.set_ylabel("num_sensors")

    plt.savefig("figs/monthly_num_common_sensors.pdf", bbox_inches='tight')
    # plt.tight_layout()
    # plt.show()
    plt.close()


def getNumber(row):
    return int(row[1][:-1])


def getMonth(row):
    return row[0].split(":")[0]


if __name__ == "__main__":
    main()