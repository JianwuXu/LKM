from __future__ import print_function
import os

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
from util import preprocessing, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import heapq
from collections import defaultdict, Counter, OrderedDict
from datetime import datetime, timedelta
from nltk.metrics import edit_distance
import helper_nmt
import time
import random

random.seed(RANDOM_SEED)

"""
Visualize test day-by-day
"""
#### Translate X --> Y, show three time series:
#### (1) input: X (_nmt_more_data/test.X)
#### (2) ground_truth: Y (_nmt_more_data/test.Y)
#### (3) translation: Y (_nmt_more_infer/infer.Y.normal)
display_length = 60 * 24  # one day
num_pick = 20  # random pick 10 sensors to show time series

"""
### on average: 22 seconds per model score calculation
### on average: 10 seconds per model time series plot
"""


def main():
    for month in ["P9", "P1", "P2"][:1]:
        hostname = misc.getHostName()
        hostname_list = [hostname]

        for hostname in hostname_list:
            script_name = os.path.basename(__file__)
            flog = open(os.path.join(FOLDER_LOGS, hostname + "_" + script_name.split("_")[0] + "_" + month + ".txt"), "w")

            time_prefix = "[overall-time]"
            begin_time = time.time()
            misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog)

            prepareForTargetMonth(month, display_length, flog, hostname)

            end_time = time.time()
            misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog)
            duration = end_time - begin_time
            misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog)
            flog.close()


def prepareForTargetMonth(month, truncate, flog, hostname):
    #### load parameters
    param_filename = "params_" + col_type + "_" + month + ".json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    filename = month + ".csv"
    data_filename = os.path.join(params["data_folder"], col_type, filename)
    print(data_filename)
    
    data_folder = os.path.join(params["data_folder"], col_type, month)

    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, col_type, month + "_" + hostname)

    base_data_folder = FOLDER_NMT_MORE_DATA
    base_infer_folder = FOLDER_NMT_MORE_INFER

    nmt_data_folder = os.path.join(base_data_folder, col_type, month)

    nmt_infer_folder = os.path.join(base_infer_folder, col_type, month + "_" + hostname)
    res_folder = os.path.join(base_infer_folder, FOLDER_RESULTS + "_" + col_type, month + "_" + hostname)

    # sensor_list = pd.read_csv(os.path.join(FOLDER_NMT_DATA, col_type, month, kw_sensors), header=None).values.flatten()

    #### group trained models based on target sensors
    trained_models = dict()
    for model in os.listdir(nmt_infer_folder):
        if not misc.isValidPathForTrainedModel(os.path.join(nmt_infer_folder, model)):
            continue
        src, tgt = model.split("#")
        if tgt not in trained_models:
            trained_models[tgt] = []
        trained_models[tgt].append(src)
    target_sensor_list = sorted(trained_models.keys())

    tot_targets = len(target_sensor_list)
    for i_tgt, target_sensor in enumerate(target_sensor_list):
        misc.log("[" + str(i_tgt + 1) + "/" + str(tot_targets) + "]Target sensor: " + target_sensor, flog)

        time_prefix = "[time]" + target_sensor
        begin_time = time.time()
        misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog, 2)

        source_sensor_list = trained_models[target_sensor]
        source_sensor_list.sort()

        decodeTranslatedTimeSeriesPerSentence(month, res_folder, target_sensor, source_sensor_list, nmt_infer_folder, nmt_data_folder,
                        params["data_preparation"], flog=flog, target_sensor_progress="[" + str(i_tgt + 1) + "/" + str(tot_targets) + "]")

        end_time = time.time()
        misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog, 2)
        duration = end_time - begin_time
        misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog, 2)


def decodeTranslatedTimeSeriesPerSentence(month, res_folder, target_sensor, source_sensor_list, nmt_infer_folder, nmt_data_folder, params,
                                           flog=None, target_sensor_progress=""):
    daily_score_folder = os.path.join(res_folder, folder_model_sentence_level_scores)
    if not os.path.exists(daily_score_folder):
        os.makedirs(daily_score_folder)

    #### get corpus-level scores
    fp_corpus_level_scores = os.path.join(nmt_infer_folder, "summary_for_" + kw_tgt_sensor + "_" + target_sensor + ".csv")
    if "201711" not in fp_corpus_level_scores:
        fp_corpus_level_scores = fp_corpus_level_scores.replace(str(month), "201711")
    corpus_level_scores = getTrainingSummary(filename=fp_corpus_level_scores)


    #### collect timestamp info -- timestamp of every test sentence
    fp_ts = os.path.join(nmt_data_folder, kw_test + "." + COL_TS)
    df_ts = pd.read_csv(fp_ts, header=None, names=[COL_TS])
    df_ts[kw_day] = df_ts.apply(getDate, axis=1)
    # print(df_ts.shape)

    #### collect ground truth -- what target sensor time series really looks like
    fp_groundtruth = os.path.join(nmt_data_folder, kw_test + "." + target_sensor)
    # df_groundtruth, timeseries_groundtruth = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnDailyBasis(fp_groundtruth, df_ts, params, display_length)
    df_groundtruth, timeseries_groundtruth = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnSentenceLevel(fp_groundtruth, df_ts, params)
    # df_groundtruth --> sentences at every timestamp
    df_groundtruth.columns = [kw_ground_truth]

    time_list = list(timeseries_groundtruth.keys())
    time_list.sort()
    # for cur_time in time_list:
    #     print(cur_time, len(timeseries_groundtruth[cur_time]))

    ######
    # Save daily score for each model
    ######
    res_columns = [kw_best_step_dev_bleu,
                   kw_avg_sentence_level_dev_bleu, kw_avg_sentence_level_dev_word_accuracy,
                   kw_sentence_level_dev_bleu_percentiles, kw_sentence_level_dev_word_accuracy_percentiles,
                   kw_bleu, kw_word_accuracy, kw_edit_distance]

    tot = len(source_sensor_list)
    for sensor_idx, source_sensor in enumerate(source_sensor_list):
        misc.log(target_sensor_progress + "[" + str(sensor_idx + 1) + "/" + str(tot) + "]Seq2Seq: " + source_sensor + "-->" + target_sensor, flog, 2)
        target_model = source_sensor + "#" + target_sensor

        if source_sensor not in corpus_level_scores.index.values:  # score not found, when len(translation) != len(gt), model skipped in nmt3_calculation
            misc.log("!!!Corpus-level NOT not found for " + target_model + ". Skip.", flog, 3)
            continue

        this_infer_folder = os.path.join(nmt_infer_folder, target_model)
        if not misc.checkExistence(this_infer_folder):
            misc.log("!!!Cannot find " + this_infer_folder + ". Skip.", flog, 3)
            return

        fp_model_res = os.path.join(daily_score_folder, target_model + ".csv")
        if os.path.exists(fp_model_res):
            misc.log("File: " + fp_model_res + " found. Skip.", flog, 3)
            continue

        #### if fp_model_res not found, do calculation
        this_model_res = pd.DataFrame(columns=res_columns, index=time_list)

        #### translation using source sensor
        fp_translation = os.path.join(this_infer_folder, kw_infer + "." + source_sensor + "." + kw_normal)
        if not os.path.exists(fp_translation):
            misc.log("Cannot find " + fp_translation + ".", flog)
            continue
        # df_translation, timeseries_translation = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnDailyBasis(fp_translation, df_ts, params, display_length)
        df_translation, timeseries_translation = helper_nmt.decodeSentenceFileForOneSensorBackToTimeSeriesOnSentenceLevel(fp_translation, df_ts, params)

        if df_translation is None and timeseries_translation is None:
            misc.log("The infer file contains empty lines. Skip this infer failure case.", flog, 2)
            continue
        
        # df_translation --> sentence at every timestamp
        df_translation.columns = [kw_translation]

        #### for each sentence -- calculate bleu and word_accuracy score -- on a daily basis
        df_sentence = df_groundtruth.merge(df_translation, left_index=True, right_index=True, how='outer')  # keep the union of timestamps

        this_model_res[kw_bleu] = df_sentence.apply(getSentenceLevelBleu, axis=1)
        this_model_res[kw_word_accuracy] = df_sentence.apply(getSentenceLevelWordAccuracy, axis=1)

        if kw_edit_distance in EVALUATION_METRIC_CANDIDATES_PER_SENTENCE:
            #### for each time series -- calculate edit distance -- on a daily basis
            # df_timeseries = pd.DataFrame(columns=[COL_TS, kw_ground_truth, kw_translation])
            _ts_gt = pd.DataFrame.from_dict(timeseries_groundtruth, orient='index')
            _ts_gt.columns = [kw_ground_truth]
            _ts_trans = pd.DataFrame.from_dict(timeseries_translation, orient='index')
            _ts_trans.columns = [kw_translation]
            df_timeseries = _ts_gt.merge(_ts_trans, left_index=True, right_index=True)
            # print(df_timeseries)
            this_model_res[kw_edit_distance] = df_timeseries.apply(compute_edit_distance, axis=1)

        else:
            #### calculating edit distance is very time consuming -- not suitable for evaluating a lot of models
            this_model_res[kw_edit_distance] = 0.0

        for dev_score in [kw_best_step_dev_bleu,
                   kw_avg_sentence_level_dev_bleu, kw_avg_sentence_level_dev_word_accuracy,
                   kw_sentence_level_dev_bleu_percentiles, kw_sentence_level_dev_word_accuracy_percentiles]:
            this_model_res[dev_score] = corpus_level_scores.loc[source_sensor][dev_score]

        #### save to file -- per model
        this_model_res.index.name = COL_TS
        this_model_res.to_csv(fp_model_res, index=True)


def getSentenceLevelBleu(row):
    return helper_nmt.compute_bleu_per_sentence(row)


def getSentenceLevelWordAccuracy(row):
    return helper_nmt.compute_word_accuracy_sentence_level(row)


def compute_edit_distance(row):
    return edit_distance(row[kw_ground_truth], row[kw_translation])


def converCharToInt(cell):
    return ord(cell) - ord('a') + 1


def getDate(row):
    return row[COL_TS].split()[0].replace("-", "")


def getTrainingSummary(filename, target_cols=None):
    df = pd.read_csv(filename)
    df = df.set_index(kw_src_sensor)
    if target_cols is None:
        return df
    else:
        return df[target_cols]


if __name__ == "__main__":
    main()
