from __future__ import print_function
import os, socket
import pandas as pd
from util import preprocessing, seq2seq, misc
from util.constants import *
import json
from pprint import pprint
import heapq
from collections import defaultdict, Counter
import sys, time
from datetime import datetime, timedelta
import shutil
import random

random.seed(RANDOM_SEED)

"""
##### train: 11/1~11/10, dev: 11/11~11/13, test: 11/14~11/16 (both inclusive)
### num_unit=20 -- 1m40s per model training
### num_unit=40 -- 2m per model training
### num_unit=64 -- 2m40s per model training
### num_unit=128 -- 5min per model training
"""


def main():
    for month in ["P9", "P1", "P2"][:1]:
        prepareForTargetMonth(month)


def prepareForTargetMonth(month):
    #### load parameters
    param_filename = "params_" + col_type + "_" + month + ".json"

    fp_params = os.path.join(FOLDER_PARAMS, param_filename)
    with open(fp_params) as f:
        params = json.load(f)
    # pprint(params)

    filename = month + ".csv"
    data_filename = os.path.join(params["data_folder"], col_type, filename)
    print(data_filename)
    
    data_folder = os.path.join(params["data_folder"], col_type, month)
    nmt_data_folder = os.path.join(FOLDER_NMT_DATA, col_type, month)

    hostname = misc.getHostName()
    nmt_model_folder = os.path.join(FOLDER_NMT_MODEL, col_type, month + "_" + hostname)
    if not os.path.exists(nmt_model_folder):
        os.makedirs(nmt_model_folder)

    sensor_list = pd.read_csv(os.path.join(nmt_data_folder, kw_sensors), header=None, comment='#').values.flatten()
    n = len(sensor_list)

    # ##### run one pair
    # misc.makeDirectories(nmt_model_folder, rmPrev=False)
    # fp_log = os.path.join(nmt_model_folder, "log_" + hostname + "_" + str(int(time.time())) + ".txt")
    # flog = open(fp_log, "w")
    # sensor_pairs = [(sensor_list[4], sensor_list[3])]
    # misc.log("sensor_pairs:" + str(sensor_pairs), flog)
    # buildSeq2SeqModelForTargetPairs(sensor_pairs, nmt_data_folder, nmt_model_folder, params["seq2seq"], flog)
    # flog.close()

    finished_target_sensors = misc.finishedTrainedTargetSensors(month, os.path.join(FOLDER_NMT_MODEL, col_type))
    print("These sensors are finished:" + str(finished_target_sensors))

    #### 187 -- 11am

    skip_these_sensors_as_targets = []

    #### specify two regular + two irregular sensors as target
    if hostname == host_lkm_laptop:
        # target_sensor_indices = [
        #     1, 2, 3, 4, 7, 8, 9, 10, 0, 6,   # done on 8/1
        # ]
        target_sensor_indices = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

    elif hostname == host_lkm_server:
        # target_sensor_indices = [20, 19, 15]  # short sensor list id=20, is the full sensor list id=187
        target_sensor_indices = [13, 14, 16, 17, 18, 21, 22, 23]  # short sensor list id=20, is the full sensor list id=187

    else:
        print("Unknown server: " + hostname + "!!! Exit.")
        exit()

    if len(target_sensor_indices) == 0:
        print("Done with host: " + hostname)
        exit()

    for target_sensor_id in target_sensor_indices:
        if target_sensor_id in finished_target_sensors:
            continue

        sensor_pairs = []
        for i in range(n):
            # if i in skip_sensor_indices:
            #     continue
            if i == target_sensor_id:
                continue
            # print(i, "-->", target_sensor_id)
            sensor_pairs.append((sensor_list[i], sensor_list[target_sensor_id]))
        # print(len(sensor_pairs))

        """
        Test on these servers first  ######################
        """
        ready_hosts = [host_lkm_laptop, host_lkm_server]
        if hostname not in ready_hosts:
            sensor_pairs = sensor_pairs[:1]
        """
        Test on these servers first  ######################
        """

        # #### train a seq2seq model using tensorflow tutorial
        misc.makeDirectories(nmt_model_folder, rmPrev=False)
        fp_log = os.path.join(nmt_model_folder, "log_" + hostname + "_" + str(int(time.time())) + ".txt")
        flog = open(fp_log, "w")
        misc.log("Running on server: " + hostname, flog)
        misc.log("Target sensor: [" + str(target_sensor_id) + "] " + str(sensor_list[target_sensor_id]), flog)
        misc.log("num_sensors=" + str(len(sensor_list)), flog)
        misc.log("sensor_list:" + ", ".join(sensor_list), flog)
        misc.log("", flog)

        time_prefix = "[overall-time]"
        begin_time = time.time()
        misc.log(time_prefix + " begin=" + str(misc.formatTime(begin_time)), flog)

        buildSeq2SeqModelForTargetPairs(sensor_pairs, nmt_data_folder, nmt_model_folder, params["seq2seq"], flog)

        #### Train all pairs
        # buildSeq2SeqModel(sensor_list, nmt_data_folder, nmt_model_folder, params["seq2seq"], flog)

        end_time = time.time()
        misc.log(time_prefix + " end=" + str(misc.formatTime(end_time)), flog)
        duration = end_time - begin_time
        misc.log(time_prefix + " duration=" + str(timedelta(seconds=duration)) + "(" + str(duration) + " seconds)", flog)

        flog.close()


def buildSeq2SeqModelForTargetPairs(target_sensor_pairs, nmt_data_folder, nmt_model_folder, params, flog):
    tot_pairs = len(target_sensor_pairs)
    for i, (source, target) in enumerate(target_sensor_pairs):
        this_model_folder = os.path.join(nmt_model_folder, source + kw_scat + target)
        misc.log("***[" + str(i + 1) + "/" + str(tot_pairs) + "]Train Seq2Seq: " + source + "-->" + target, flog)
        if checkIfFinishTraining(this_model_folder, last_step=params["num_train_steps"]):
            misc.log("Found " + this_model_folder + ". Skip.", flog, 2)
            continue

        if os.path.exists(this_model_folder):
            print("remove unfinished model " + this_model_folder)
            shutil.rmtree(this_model_folder)
        seq2seq.trainForSensorPairs(source, target, nmt_data_folder, this_model_folder, params, flog=flog)


def checkIfFinishTraining(this_model_folder, last_step=1000):
    if not os.path.exists(this_model_folder):
        return False
    for kw in ["index", "meta", "data-00000-of-00001"]:
        fp = os.path.join(this_model_folder, "translate.ckpt-" + str(last_step) + "." + kw)
        if not os.path.exists(fp):
            return False
    return True


def buildSeq2SeqModel(sensor_list, nmt_data_folder, nmt_model_folder, params, flog):
    num_sensors = len(sensor_list)
    for i in range(num_sensors):
        for j in range(num_sensors):
            if i == j: continue
            misc.log("***Train Seq2Seq (" + str(i) + "-->" + str(j) + "): " + sensor_list[i] + "-->" + sensor_list[j], flog)
            this_model_folder = os.path.join(nmt_model_folder, sensor_list[i] + kw_scat + sensor_list[j])
            if os.path.exists(this_model_folder):
                misc.log("\tModel already trained. Skip.")
                continue
            seq2seq.trainForSensorPairs(sensor_list[i], sensor_list[j], nmt_data_folder, this_model_folder, params, flog=flog)


if __name__ == "__main__":
    main()
