from __future__ import print_function
from __future__ import division

import os
import pandas as pd
from util.constants import *
import nmt.scripts.bleu as bleu


def get_model_server_assignment(month, res_folder, score_folder):
    model_to_folder = dict()
    for folder in os.listdir(res_folder):
        if month not in folder:
            continue
        this_res_folder = os.path.join(res_folder, folder, score_folder)
        for fn in os.listdir(this_res_folder):
            this_model = fn.replace(".csv", "")
            model_to_folder[this_model] = folder
    return model_to_folder


def decodeSentenceFileForOneSensorBackToTimeSeriesOnSentenceLevel(sensor_filename, df_ts, params):
    #### get sensor sentence file
    df_groundtruth = pd.read_csv(sensor_filename, header=None, names=[kw_sentence])

    # in this case, the infer file contains empty lines (prediction failure), so skip this model
    if df_groundtruth.shape[0] != df_ts.shape[0]:
        return None, None

    # assign timestamp to ground truth (target sensor time series)
    df_groundtruth = df_groundtruth.merge(df_ts, left_index=True, right_index=True,
                                          how='outer')  # keep the union of timestamps
    # print(df_groundtruth.shape)

    assert df_ts.shape[0] == df_groundtruth.shape[0]

    # convert sentence back to real time series on sentence level
    df_groundtruth[kw_timeseries] = df_groundtruth.apply(decodeOneSentence, axis=1, char_step=params["char_step"])

    df_groundtruth = df_groundtruth.set_index(COL_TS)
    timeseries_dict = df_groundtruth[kw_timeseries].to_dict()

    df_groundtruth = df_groundtruth[[kw_sentence]]
    return df_groundtruth, timeseries_dict


def decodeOneSentence(row, char_step):
    word_list = row[kw_sentence].split()
    timeseries = word_list[0]
    for word in word_list[1:]:
        timeseries += word[-char_step:]
    return timeseries


def decodeSentenceFileForOneSensorBackToTimeSeriesOnDailyBasis(sensor_filename, df_ts, params, display_length):
    #### get sensor sentence file
    df_groundtruth = pd.read_csv(sensor_filename, header=None, names=[kw_sentence])

    # in this case, the infer file contains empty lines (prediction failure), so skip this model
    if df_groundtruth.shape[0] != df_ts.shape[0]:
        return None, None

    # assign timestamp to ground truth (target sensor time series)
    df_groundtruth = df_groundtruth.merge(df_ts, left_index=True, right_index=True,
                                          how='outer')  # keep the union of timestamps
    # print(df_groundtruth.shape)

    assert df_ts.shape[0] == df_groundtruth.shape[0]

    # convert sentence back to real time series on a daily-basis
    timeseries_dict = {}
    for day, dfd in df_groundtruth.groupby(kw_day):
        timeseries = decodeSentenceFileBackToTimeSeries(dfd[kw_sentence], params, display_length)
        timeseries_dict[day] = timeseries

    # if sensor_filename == "_nmt_more_infer/categorical/201711/vm-pida_CSO.19LCB20AP204XD07#vm-pida_CSO.11EK__20:BMS_11_1.BO08/infer.vm-pida_CSO.19LCB20AP204XD07.normal":
    # exit()

    df_groundtruth = df_groundtruth.set_index(COL_TS)
    df_groundtruth = df_groundtruth[[kw_day, kw_sentence]]

    return df_groundtruth, timeseries_dict


def decodeSentenceFileBackToTimeSeries(df_sentences, params, truncate):
    wlen, cstep = params["word_length"], params["char_step"]
    slen, wstep = params["sentence_length"], params["word_step"]

    if wstep > slen:
        print("word_step(wstep=" + str(wstep) + ") cannot be greater than sentence_length(slen=" + str(slen) + ")")
        exit()

    #### 1. convert sentences back to word list according to wlen
    word_list = None
    for idx in df_sentences.index:
        words = df_sentences.loc[idx]
        words = words.split()
        if word_list is None:
            word_list = words
        else:
            word_list.extend(words[-wstep:])
    # print(len(word_list))
    assert len(word_list) != 0

    #### 2. convert word list back to time series
    timeseries = convertSentenceBackToTimeSeries(word_list, wlen, cstep)
    #### truncate to the specified display length
    #### e.g., if deconde sentences in one day back to time series
    ####        num_records_per_day = 60 * 24 = 1440
    ####        however, converted len(timeseries) = 1449 (9 more chars come from the next day)
    timeseries = timeseries[:truncate]

    #### make sure len_timeseries % slen == 0
    len_timeseries = len(timeseries)
    if len_timeseries % slen != 0:
        new_len = int(len_timeseries / slen) * slen
        timeseries = timeseries[:new_len]
    return timeseries


def convertSentenceBackToTimeSeries(word_list, wlen, cstep):
    if cstep > wlen:
        print("char_step(cstep=" + str(cstep) + ") cannot be greater than word_length(wlen=" + str(wlen) + ")")
        exit()

    timeseries = word_list[0]
    ts_len = len(timeseries)
    for w in word_list[1:]:
        timeseries += w[-cstep:]
        ts_len += cstep

    return timeseries


# copied from tensorflow nmt tutorial
# Follow //transconsole/localization/machine_translation/metrics/bleu_calc.py
def compute_bleu(df):
    """Compute BLEU scores and handling BPE."""
    max_order = 4
    smooth = False

    reference_text = []
    reference_text.append(df[kw_ground_truth].values)

    per_segment_references = []
    for references in zip(*reference_text):
        reference_list = []
        for reference in references:
            reference = reference.strip()
            reference_list.append(reference.split(" "))
        per_segment_references.append(reference_list)

    translations = []
    for idx in df.index:
        line = df.loc[idx][kw_translation]
        translations.append(line.split(" "))

    # bleu_score, precisions, bp, ratio, translation_length, reference_length
    bleu_score, _, _, _, _, _ = bleu.compute_bleu(
        per_segment_references, translations, max_order, smooth)
    return 100 * bleu_score


# copied from tensorflow nmt tutorial
def compute_word_accuracy(dfd):
    """Compute accuracy on per word basis."""
    df_wa = dfd.apply(computeWordMatchForEachSentence, axis=1)
    total_acc = df_wa.sum()
    total_count = df_wa.shape[0]

    # total_acc, total_count = 0., 0.
    # for idx in dfd.index:
    #     labels = dfd.loc[idx][kw_ground_truth].split(" ")
    #     preds = dfd.loc[idx][kw_translation].split(" ")
    #     match = 0.0
    #     for pos in range(min(len(labels), len(preds))):
    #         if labels[pos] == preds[pos]:
    #             match += 1
    #     total_acc += 100 * match / max(len(labels), len(preds))
    #     total_count += 1

    # print(total_acc, total_count)
    return total_acc / total_count


def computeWordMatchForEachSentence(row):
    labels = row[kw_ground_truth].split(" ")
    preds = row[kw_translation].split(" ")
    match = 0.0
    for pos in range(min(len(labels), len(preds))):
        if labels[pos] == preds[pos]:
            match += 1
    this_acc = 100 * match / max(len(labels), len(preds))
    return this_acc


# copied from tensorflow nmt tutorial
# Follow //transconsole/localization/machine_translation/metrics/bleu_calc.py
def compute_bleu_per_sentence(row):  # only one row in df
    """Compute BLEU scores and handling BPE."""
    max_order = 4
    smooth = False

    per_segment_references = [[row[kw_ground_truth].split()]]
    translations = [row[kw_translation].split()]

    # bleu_score, precisions, bp, ratio, translation_length, reference_length
    bleu_score, _, _, _, _, _ = bleu.compute_bleu(
        per_segment_references, translations, max_order, smooth)
    return 100 * bleu_score


# copied from tensorflow nmt tutorial
def compute_word_accuracy_sentence_level(row):
    """Compute accuracy on per word basis."""

    labels = row[kw_ground_truth].split(" ")
    preds = row[kw_translation].split(" ")
    match = 0.0
    for pos in range(min(len(labels), len(preds))):
        if labels[pos] == preds[pos]:
            match += 1
    this_acc = 100 * match / max(len(labels), len(preds))
    return this_acc

